import { NextRequest, NextResponse } from 'next/server';
import { readApiConfig, writeApiConfig } from '@/lib/api-config';

export const runtime = 'nodejs';

export async function GET() {
  try {
    const config = await readApiConfig();
    return NextResponse.json({
      configured: Boolean(config.apiKey),
      model: config.model,
      baseUrl: config.baseUrl,
    });
  } catch {
    return NextResponse.json({ error: '无法读取本地 API 配置文件。' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  if (!sameOrigin(request))
    return NextResponse.json({ error: '不允许跨站修改本地 API 配置。' }, { status: 403 });
  try {
    const { apiKey, model, baseUrl, action } = (await request.json()) as {
      apiKey?: string;
      model?: string;
      baseUrl?: string;
      action?: string;
    };
    const saved = await readApiConfig();
    const newKey = apiKey?.trim() || '';
    const effectiveKey = newKey || saved.apiKey;
    if (newKey && newKey.length < 8)
      return NextResponse.json({ error: 'API 密钥格式不正确。' }, { status: 400 });
    if (!effectiveKey)
      return NextResponse.json({ error: '请先填写 API 密钥。' }, { status: 400 });
    const normalizedBaseUrl = normalizeBaseUrl(baseUrl || saved.baseUrl);
    if (!normalizedBaseUrl)
      return NextResponse.json({ error: 'API 地址格式不正确。' }, { status: 400 });
    if (action === 'test') {
      const modelResponse = await fetch(`${normalizedBaseUrl}/models`, {
        headers: { Authorization: `Bearer ${effectiveKey}` },
        signal: AbortSignal.timeout(20000),
      });
      const raw = await modelResponse.text();
      let payload: { data?: Array<{ id?: string }>; error?: { message?: string } } = {};
      try {
        payload = JSON.parse(raw);
      } catch {
        payload = { error: { message: raw } };
      }
      if (!modelResponse.ok)
        return NextResponse.json(
          { error: payload.error?.message || `连接失败（${modelResponse.status}）` },
          { status: 400 },
        );
      const models = (payload.data || [])
        .map((item) => item.id)
        .filter((id): id is string => Boolean(id));
      return NextResponse.json({ connected: true, models });
    }
    const selectedModel = model?.trim() || saved.model;
    await writeApiConfig({ apiKey: effectiveKey, model: selectedModel, baseUrl: normalizedBaseUrl });
    const response = NextResponse.json({ configured: true, model: selectedModel, baseUrl: normalizedBaseUrl });
    for (const name of ['food_image_api_key', 'food_image_model', 'food_image_base_url'])
      response.cookies.set(name, '', { path: '/', maxAge: 0 });
    return response;
  } catch (error) {
    console.error('API config save failed:', error instanceof Error ? error.message : error);
    const message = error instanceof Error ? error.message : '';
    return NextResponse.json({ error: message.includes('配置服务未启动') ? message : message.includes('timeout') || message.includes('aborted') ? '连接超时，请检查 API 地址或网络后重试。' : '无法连接或保存 API 设置，请检查地址、网络及本机目录权限后重试。' }, { status: 500 });
  }
}

function normalizeBaseUrl(value: string) {
  try {
    const url = new URL(value.trim());
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    return url.toString().replace(/\/$/, '');
  } catch {
    return null;
  }
}

export async function DELETE(request: NextRequest) {
  if (!sameOrigin(request))
    return NextResponse.json({ error: '不允许跨站修改本地 API 配置。' }, { status: 403 });
  try {
    const saved = await readApiConfig();
    await writeApiConfig({ ...saved, apiKey: '' });
    const response = NextResponse.json({ configured: false });
    response.cookies.set('food_image_api_key', '', { path: '/', maxAge: 0 });
    return response;
  } catch {
    return NextResponse.json({ error: '无法清除本地 API 密钥。' }, { status: 500 });
  }
}

function sameOrigin(request: NextRequest) {
  const origin = request.headers.get('origin');
  return !origin || origin === new URL(request.url).origin;
}
