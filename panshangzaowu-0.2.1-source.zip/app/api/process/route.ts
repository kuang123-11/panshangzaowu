import { NextRequest, NextResponse } from 'next/server';
import { readApiConfig } from '@/lib/api-config';
import { getContainerPreset } from '@/lib/container-presets';
import { getOptimizationStrengthProfile } from '@/lib/optimization-strength';
import { PROCESS_TIMEOUT_MS } from '@/lib/processing';
export const runtime = 'nodejs';
function formText(form: FormData, key: string, fallback = '') {
  const value = form.get(key);
  return typeof value === 'string' ? value : fallback;
}
const modePrompts: Record<string, string> = {
  material:
    'Make a faithful photographic food asset from the supplied image. Preserve the existing food pixels, natural texture, color variation, glaze and highlights as closely as possible. Complete the selected vessel so it is entirely visible. Correct exposure or white balance gently only where necessary.',
  cutout:
    'Only remove the background. Preserve the dish, food, plate, colors, shape, texture, lighting and composition exactly.',
  enhance:
    'Correct exposure and white balance subtly while keeping the original food texture, natural color and existing highlights.',
  angle:
    'Improve the food presentation and reconstruct the camera viewpoint to the requested angle while preserving the exact dish identity, ingredients, portion and arrangement.',
  complete:
    'Naturally complete all cropped or missing parts of the food and plate, then improve the presentation and reconstruct the camera viewpoint to the requested angle.',
  plate:
    'Place the food into the chosen complete container. Preserve the original food identity and natural photographic texture.',
  fusion:
    'Create one believable finished dish from the supplied food photographs. Preserve recognizable ingredients, natural food texture and realistic scale; do not make a collage.',
  bundle:
    'Create one cohesive meal-set presentation from all supplied dish images. Keep every selected dish recognizable and complete, arrange them with balanced spacing, realistic scale and consistent perspective, and do not merge or replace dishes. Remove any forks, spoons, chopsticks, hands or other loose props visible in the source images; keep only the food and its complete containers.',
};
export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin');
  if (origin && origin !== new URL(request.url).origin)
    return NextResponse.json({ error: '不允许跨站使用本地 API。' }, { status: 403 });
  const contentLength = Number(request.headers.get('content-length') || 0);
  if (contentLength > 24 * 1024 * 1024)
    return NextResponse.json(
      { error: '上传内容超过 24 MB，请缩小图片后重试。' },
      { status: 413 },
    );
  try {
    const config = await readApiConfig();
    const apiKey = config.apiKey;
    if (!apiKey)
      return NextResponse.json(
        { error: '尚未配置 API 密钥，请点击页面右上角的设置按钮填写。' },
        { status: 503 },
      );
    const incoming = await request.formData();
    const images = incoming.getAll('image').filter((item): item is File => item instanceof File);
    const plate = incoming.get('plate');
    const backdrop = incoming.get('backdrop');
    const mode = formText(incoming, 'mode', 'enhance');
    const fusionStyle = formText(incoming, 'fusionStyle', 'new_plate');
    const sceneStyle = formText(incoming, 'sceneStyle', 'cream') === 'slate' ? 'dark slate tabletop' : 'warm cream tabletop';
    const containerPresetId = formText(incoming, 'containerPreset', mode === 'plate' || (mode === 'fusion' && fusionStyle === 'new_plate') ? 'round-medium' : 'original');
    const angle = formText(incoming, 'angle', '保持原角度');
    const size = formText(incoming, 'size', '1024x1024');
    const requestedStrength = Number(formText(incoming, 'strength', '35'));
    const strength = Number.isFinite(requestedStrength) ? Math.min(100, Math.max(20, requestedStrength)) : 35;
    const strengthProfile = getOptimizationStrengthProfile(strength);
    const protectFood = incoming.get('protectFood') !== 'false';
    const customInstruction = formText(incoming, 'customInstruction').trim().slice(0, 1000);
    const selectedModel = formText(incoming, 'model', config.model).trim();
    const baseUrl = normalizeBaseUrl(config.baseUrl);
    if (!baseUrl)
      return NextResponse.json(
        { error: 'API 地址格式不正确。' },
        { status: 400 },
      );
    if (!images.length)
      return NextResponse.json({ error: '没有收到图片。' }, { status: 400 });
    const uploads = [...images, plate, backdrop].filter((item): item is File => item instanceof File);
    if (uploads.reduce((total, item) => total + item.size, 0) > 24 * 1024 * 1024)
      return NextResponse.json({ error: '上传内容超过 24 MB，请缩小图片后重试。' }, { status: 413 });
    if (uploads.some((item) => !item.size || !['image/png', 'image/jpeg', 'image/webp'].includes(item.type)))
      return NextResponse.json({ error: '请上传有效的 PNG、JPG 或 WebP 图片。' }, { status: 400 });
    if (images.length > 8)
      return NextResponse.json({ error: '一次最多处理 8 张图片。' }, { status: 400 });
    if (mode === 'fusion' && (images.length < 2 || images.length > 8))
      return NextResponse.json({ error: '多菜融合请选择 2–8 道菜。' }, { status: 400 });
    const useCustomContainer = plate instanceof File && plate.size > 0 && !(mode === 'fusion' && fusionStyle === 'into_main');
    const preset = getContainerPreset(
      containerPresetId === 'original' && (mode === 'plate' || (mode === 'fusion' && fusionStyle === 'new_plate'))
        ? 'round-medium'
        : containerPresetId,
    );
    const containerInstruction = mode === 'fusion' && fusionStyle === 'into_main'
      ? 'Image 1 is the main dish and must remain the base. Keep its original vessel and overall arrangement. Add only suitable food elements from Images 2 onward into this main dish, in natural amounts and positions. Do not include any donor plate, bowl, box, rim or background.'
      : useCustomContainer
        ? `The final supplied image is the empty container reference. Use that container only, matching its shape, material, color, compartments and complete rim; do not copy its background.`
        : preset.id !== 'original'
          ? `Use ${preset.prompt} as the sole final vessel. Preserve its entire silhouette, rim and any compartment dividers. Do not retain the source containers.`
          : 'Keep the original complete container, including its continuous outer rim and base.';
    const fusionInstruction = mode === 'fusion'
      ? fusionStyle === 'into_main'
        ? 'The final image must read as a single naturally combined dish centered on Image 1, not separate dishes placed beside one another.'
        : 'Combine selected foods from all source images into one coherent new dish in the chosen vessel. Balance portions and scale so the foods naturally share the same plate or box. For a compartment bento, distribute foods logically between compartments. Never show multiple original containers.'
      : '';
    const prompt = [
      'Edit the supplied photograph conservatively for a standalone menu asset. Treat the original food as the visual ground truth.',
      modePrompts[mode] || modePrompts.enhance,
      containerInstruction,
      fusionInstruction,
      mode === 'fusion' ? `Images 1 through ${images.length} are the selected food sources in order.` : '',
      `Requested camera angle: ${angle}. Enhancement setting: ${strength}% (${strengthProfile.label}). ${strengthProfile.instruction} This setting may affect lighting and white balance only, never the food texture or shape.`,
      'Keep the original food colors and realistic surface detail. Do not add sharpening, clarity, HDR, strong local contrast, excessive red or orange saturation, plastic-looking glaze, extra oil shine, fake highlights, painted texture or invented ingredient detail.',
      protectFood
        ? 'Critical invariant: preserve the food type, ingredient identity, portion size and original plating relationship.'
        : '',
      customInstruction ? `Additional user instruction: ${customInstruction}` : '',
      mode === 'bundle'
        ? backdrop instanceof File
          ? 'Use the final supplied image as the complete scene background. Place the dishes naturally into that scene with coherent scale, perspective and contact shadows. Fill the entire frame with this background; output must be fully opaque, never transparent or checkerboard.'
          : `Arrange the dishes automatically into a believable meal scene on a ${sceneStyle}. Balance their sizes and front-to-back placement with natural contact shadows and generous framing. Fill the entire frame with the tabletop background; output must be fully opaque, never transparent, checkerboard or green-screen.`
        : 'Output an opaque PNG on a perfectly flat, evenly lit chroma-key green screen (#00FF00, RGB 0 255 0). Do not use a blue or cyan screen, gradients, shadows, texture, transparency or a checkerboard. Reconstruct every cropped or missing part of the complete food and vessel, especially the white upper rim behind the food and the lower outer edge. Keep the entire vessel silhouette inside the canvas with a clear 8–12% green margin on every side. Put exactly the same pure green in every genuine background opening, including enclosed handle holes and gaps between the vessel and its handles, even when not connected to the exterior background. Keep the vessel interior, white ceramic, food surfaces and leafy vegetables solid and natural: never paint green-screen color over these foreground surfaces and never invent holes. Preserve green ingredients with their original texture and varied natural greens. No isolated fragments, dark outline, halo, green spill, table, props, text, logo, watermark, frame or cast shadow outside the vessel. The green screen, including enclosed background openings, will be removed locally after generation.',
    ]
      .filter(Boolean)
      .join(' ');
    const body = new FormData();
    body.append('model', selectedModel);
    images.slice(0, 8).forEach((image) => body.append('image[]', image, image.name));
    if (useCustomContainer)
      body.append('image[]', plate, plate.name);
    if (backdrop instanceof File && backdrop.size > 0)
      body.append('image[]', backdrop, backdrop.name);
    body.append('prompt', prompt);
    body.append('size', size);
    body.append('quality', 'high');
    body.append('output_format', 'png');
    if (!(mode === 'bundle' && backdrop instanceof File))
      body.append('background', 'opaque');
    let result: {
      data?: Array<{ b64_json?: string; url?: string }>;
      error?: { message?: string };
    } = {};
    const response = await fetch(`${baseUrl}/images/edits`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}` },
      body,
      signal: AbortSignal.any([request.signal, AbortSignal.timeout(PROCESS_TIMEOUT_MS)]),
    });
    const raw = await response.text();
    try {
      result = JSON.parse(raw);
    } catch {
      result = {
        error: { message: raw || `图像服务返回错误（${response.status}）` },
      };
    }
    if (!response.ok) {
      const message = result.error?.message || '图像服务请求失败';
      return NextResponse.json(
        { error: `图像 API 请求失败（HTTP ${response.status}）：${message}` },
        { status: response.status },
      );
    }
    const output = result.data?.[0];
    if (!output || (!output.b64_json && !output.url)) throw new Error('图像服务没有返回可用图片，请检查所选模型是否支持图像编辑。');
    return NextResponse.json({
      image: output.b64_json
        ? `data:image/png;base64,${output.b64_json}`
        : output.url,
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error && (error.name === 'TimeoutError' || error.name === 'AbortError')
            ? '本张图片等待超过十分钟，请检查网络或服务端任务状态后再决定是否重试。'
            : error instanceof Error ? error.message : '处理失败，请稍后重试。',
      },
      { status: 500 },
    );
  }
}

function normalizeBaseUrl(value: string) {
  try {
    const url = new URL(value.trim());
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    return url.toString().replace(/\/$/, '');
  } catch {
    return null;
  }
}
