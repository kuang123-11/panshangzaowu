'use client';

import {
  ChangeEvent,
  DragEvent,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  Check,
  ChevronDown,
  ClipboardPaste,
  Copy,
  Download,
  FileArchive,
  FolderOpen,
  ImagePlus,
  LoaderCircle,
  MoreHorizontal,
  Plus,
  Settings2,
  Sparkles,
  Trash2,
  Upload,
  Utensils,
  Wallpaper,
  X,
  ZoomIn,
} from 'lucide-react';
import JSZip from 'jszip';
import { Button } from '@/components/ui/button';
import { ContainerThumbnail } from '@/components/container-thumbnail';
import { ImageCopyMenu, copyImageToClipboard } from '@/components/image-copy-menu';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { containerPresets, getContainerPreset } from '@/lib/container-presets';
import { getOptimizationStrengthProfile } from '@/lib/optimization-strength';
import { PROCESS_TIMEOUT_MS } from '@/lib/processing';
import { removeGreenScreen } from '@/lib/green-screen';

type JobStatus = 'ready' | 'processing' | 'done' | 'error';
type FoodJob = {
  id: string;
  file: File;
  name: string;
  src: string;
  status: JobStatus;
  progress: number;
  result?: string;
  error?: string;
};
type SavedProject = { id: string; name: string; updatedAt: number };
type BundleLayout = { x: number; y: number; scale: number; order: number };
type ProjectData = SavedProject & {
  projectType?: 'single' | 'bundle' | 'fusion';
  containerPreset?: string;
  fusionStyle?: 'new_plate' | 'into_main';
  fusionSelection?: string[];
  fusionMainId?: string;
  fusionResult?: string;
  bundleSelection?: string[];
  bundleLayouts?: Record<string, BundleLayout>;
  bundleMethod?: 'local' | 'ai';
  bundlePlacement?: 'manual' | 'auto';
  bundleBackground?: 'cream' | 'slate';
  customInstruction?: string;
  mode?: string;
  angle?: string;
  size?: string;
  strength?: number;
  protectFood?: boolean;
  jobs: FoodJob[];
  plate: { file: File; src: string } | null;
  backdrop: { file: File; src: string } | null;
};
type WebMcpContext = {
  registerTool: (
    tool: object,
    options?: { signal?: AbortSignal },
  ) => void | Promise<void>;
};
type SettingsResponse = {
  configured?: boolean;
  baseUrl?: string;
  model?: string;
  models?: string[];
  error?: string;
};
type ProcessResponse = { image?: string; error?: string };

async function readJson<T>(response: Response): Promise<T> {
  return (await response.json()) as T;
}

const modes = [
  {
    id: 'material',
    number: '01',
    title: '素材处理',
    detail: '优化菜品并输出透明素材',
    icon: Sparkles,
  },
] as const;
const angles = ['保持原角度', '正俯拍 90°', '斜俯拍 45°', '低角度 30°'];
const sizes = ['1024 × 1024', '1536 × 1024', '1024 × 1536', '2048 × 2048'];
function defaultBundleLayout(index: number, total: number): BundleLayout {
  const columns = total <= 3 ? total : Math.ceil(Math.sqrt(total));
  const rows = Math.ceil(total / columns);
  const row = Math.floor(index / columns);
  const itemsInRow = Math.min(columns, total - row * columns);
  return {
    x: (index % columns + 0.5 + (columns - itemsInRow) / 2) / columns,
    y: (row + 0.5) / rows,
    scale: Math.min(0.74 / columns, 0.74 / rows),
    order: index,
  };
}
const customPresets = [
  '画面中只保留一盘菜',
  '去掉被提起或夹起的食材',
  '去除手、筷子和多余餐具',
];
const defaultImageModels = [
  {
    id: 'gpt-image-2.5-sunburst',
    name: 'GPT Image 2.5 Sunburst',
    detail: '精细编辑，推荐',
  },
  {
    id: 'gpt-image-2.5-flare',
    name: 'GPT Image 2.5 Flare',
    detail: '速度更快',
  },
  { id: 'gpt-image-2', name: 'GPT Image 2', detail: '稳定通用' },
];
const MAX_UPLOAD_BYTES = 7 * 1024 * 1024;
const MAX_INPUT_EDGE = 2400;
const PROJECT_INDEX_KEY = 'food-image-projects';

function openProjectDb() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open('food-image-workbench', 1);
    request.onupgradeneeded = () =>
      request.result.createObjectStore('projects', { keyPath: 'id' });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function putProject(project: ProjectData) {
  const db = await openProjectDb();
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction('projects', 'readwrite');
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error || new Error('项目保存已中止'));
      transaction.objectStore('projects').put(project);
    });
  } finally {
    db.close();
  }
}

async function getProject(id: string) {
  const db = await openProjectDb();
  const value = await new Promise<ProjectData | undefined>((resolve, reject) => {
    const request = db.transaction('projects').objectStore('projects').get(id);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  db.close();
  return value;
}

async function deleteProjectRecord(id: string) {
  const db = await openProjectDb();
  await new Promise<void>((resolve, reject) => {
    const request = db.transaction('projects', 'readwrite').objectStore('projects').delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
  db.close();
}

async function optimizeInput(file: File, maxBytes = MAX_UPLOAD_BYTES, maxEdge = MAX_INPUT_EDGE): Promise<File> {
  if (
    file.size <= maxBytes &&
    ['image/png', 'image/jpeg', 'image/webp'].includes(file.type)
  )
    return file;
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(
    1,
    maxEdge / Math.max(bitmap.width, bitmap.height),
  );
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d');
  if (!context) {
    bitmap.close();
    return file;
  }
  context.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  const outputType = file.type === 'image/jpeg' ? 'image/jpeg' : 'image/webp';
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, outputType, 0.9),
  );
  if (!blob) return file;
  return new File([blob], `${file.name.replace(/\.[^.]+$/, '')}-已优化.${outputType === 'image/jpeg' ? 'jpg' : 'webp'}`, {
    type: outputType,
    lastModified: file.lastModified,
  });
}

function imageMimeFromName(name: string) {
  const ext = name.toLowerCase().split('.').pop();
  return ext === 'jpg' || ext === 'jpeg'
    ? 'image/jpeg'
    : ext === 'webp'
      ? 'image/webp'
      : ext === 'gif'
        ? 'image/gif'
        : 'image/png';
}

function blobToDataUrl(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === 'string' ? resolve(reader.result) : reject(new Error('图片编码失败'));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}


function cleanAlphaArtifacts(pixels: Uint8ClampedArray, width: number, height: number) {
  const count = width * height;
  const visited = new Uint8Array(count);
  const queue = new Int32Array(count);
  const maxSpeckArea = Math.min(160, Math.max(12, Math.round(count / 20000)));

  // Remove only tiny isolated opaque fragments. The plate and food remain
  // untouched even if their own edge has a soft alpha transition.
  for (let start = 0; start < count; start += 1) {
    if (visited[start] || pixels[start * 4 + 3] < 96) continue;
    let head = 0;
    let tail = 1;
    queue[0] = start;
    visited[start] = 1;
    while (head < tail) {
      const position = queue[head++];
      const x = position % width;
      const y = Math.floor(position / width);
      for (let dy = -1; dy <= 1; dy += 1) {
        for (let dx = -1; dx <= 1; dx += 1) {
          if (!dx && !dy) continue;
          const nx = x + dx;
          const ny = y + dy;
          if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
          const neighbor = ny * width + nx;
          if (visited[neighbor] || pixels[neighbor * 4 + 3] < 96) continue;
          visited[neighbor] = 1;
          queue[tail++] = neighbor;
        }
      }
    }
    if (tail <= maxSpeckArea) {
      for (let index = 0; index < tail; index += 1)
        pixels[queue[index] * 4 + 3] = 0;
    }
  }

  const afterSpecks = new Uint8ClampedArray(pixels);
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const offset = (y * width + x) * 4;
      const alpha = afterSpecks[offset + 3];
      if (!alpha) continue;
      if (alpha < 96) {
        let attached = false;
        for (let dy = -2; dy <= 2 && !attached; dy += 1) {
          for (let dx = -2; dx <= 2; dx += 1) {
            const nx = x + dx;
            const ny = y + dy;
            if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
            if (afterSpecks[(ny * width + nx) * 4 + 3] >= 96) {
              attached = true;
              break;
            }
          }
        }
        if (!attached) {
          pixels[offset + 3] = 0;
          continue;
        }
      }

      // A dark pixel on the outside of a pale plate is usually edge color
      // contamination. Borrow the nearest solid neutral plate color without
      // reducing alpha, so thin white rims do not become translucent.
      const brightness = (afterSpecks[offset] + afterSpecks[offset + 1] + afterSpecks[offset + 2]) / 3;
      if (brightness >= 120) continue;
      let touchesClear = false;
      for (let dy = -1; dy <= 1 && !touchesClear; dy += 1) {
        for (let dx = -1; dx <= 1; dx += 1) {
          const nx = x + dx;
          const ny = y + dy;
          if (nx < 0 || nx >= width || ny < 0 || ny >= height || afterSpecks[(ny * width + nx) * 4 + 3] < 16) {
            touchesClear = true;
            break;
          }
        }
      }
      if (!touchesClear) continue;
      let nearest = -1;
      let nearestDistance = Infinity;
      for (let dy = -4; dy <= 4; dy += 1) {
        for (let dx = -4; dx <= 4; dx += 1) {
          const nx = x + dx;
          const ny = y + dy;
          if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
          const candidate = (ny * width + nx) * 4;
          if (afterSpecks[candidate + 3] < 240) continue;
          const r = afterSpecks[candidate];
          const g = afterSpecks[candidate + 1];
          const b = afterSpecks[candidate + 2];
          if ((r + g + b) / 3 < 185 || Math.max(r, g, b) - Math.min(r, g, b) > 35) continue;
          const distance = dx * dx + dy * dy;
          if (distance < nearestDistance) {
            nearestDistance = distance;
            nearest = candidate;
          }
        }
      }
      if (nearest >= 0) {
        pixels[offset] = afterSpecks[nearest];
        pixels[offset + 1] = afterSpecks[nearest + 1];
        pixels[offset + 2] = afterSpecks[nearest + 2];
      }
    }
  }
}

async function ensureTransparentPng(blob: Blob, requireGreenMatte = false) {
  const bitmap = await createImageBitmap(blob);
  const canvas = document.createElement('canvas');
  canvas.width = bitmap.width;
  canvas.height = bitmap.height;
  const context = canvas.getContext('2d', { willReadFrequently: true });
  if (!context) {
    bitmap.close();
    throw new Error('浏览器无法检查透明通道');
  }
  context.drawImage(bitmap, 0, 0);
  bitmap.close();
  const image = context.getImageData(0, 0, canvas.width, canvas.height);
  removeGreenScreen(image.data, canvas.width, canvas.height, requireGreenMatte);
  cleanAlphaArtifacts(image.data, canvas.width, canvas.height);
  context.putImageData(image, 0, 0);
  return await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error('透明 PNG 转换失败')), 'image/png'));
}

export default function Home() {
  const [projects, setProjects] = useState<SavedProject[]>([]);
  const [projectId, setProjectId] = useState('');
  const [projectName, setProjectName] = useState('未命名项目');
  const [projectReady, setProjectReady] = useState(false);
  const [projectType, setProjectType] = useState<'single' | 'bundle' | 'fusion'>('single');
  const [containerPreset, setContainerPreset] = useState('original');
  const [containerListOpen, setContainerListOpen] = useState(false);
  const [fusionStyle, setFusionStyle] = useState<'new_plate' | 'into_main'>('new_plate');
  const [fusionSelection, setFusionSelection] = useState<string[]>([]);
  const [fusionMainId, setFusionMainId] = useState('');
  const [fusionResult, setFusionResult] = useState('');
  const [fusionProcessing, setFusionProcessing] = useState(false);
  const [fusionError, setFusionError] = useState('');
  const [bundleSelection, setBundleSelection] = useState<string[]>([]);
  const [bundleLayouts, setBundleLayouts] = useState<Record<string, BundleLayout>>({});
  const [bundleMethod, setBundleMethod] = useState<'local' | 'ai'>('local');
  const [bundlePlacement, setBundlePlacement] = useState<'manual' | 'auto'>('manual');
  const [bundleBackground, setBundleBackground] = useState<'cream' | 'slate'>('cream');
  const [bundleResult, setBundleResult] = useState('');
  const [bundleProcessing, setBundleProcessing] = useState(false);
  const bundleStageRef = useRef<HTMLDivElement>(null);
  const activeBundleDrag = useRef<string | null>(null);
  const activeBundleResize = useRef<{ id: string; startX: number; startY: number; startScale: number } | null>(null);
  const [mode, setMode] = useState('material');
  const [jobs, setJobs] = useState<FoodJob[]>([]);
  const [plate, setPlate] = useState<{ file: File; src: string } | null>(null);
  const [backdrop, setBackdrop] = useState<{ file: File; src: string } | null>(null);
  const [angle, setAngle] = useState('斜俯拍 45°');
  const [size, setSize] = useState('1024 × 1024');
  const [strength, setStrength] = useState(35);
  const [protectFood, setProtectFood] = useState(true);
  const [customInstruction, setCustomInstruction] = useState('');
  const [dragging, setDragging] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState<{ src: string; name: string } | null>(null);
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [apiConfigured, setApiConfigured] = useState(false);
  const [apiSettingMessage, setApiSettingMessage] = useState('');
  const [apiMessageStatus, setApiMessageStatus] = useState<'info' | 'success' | 'error'>('info');
  const [savedApiSettings, setSavedApiSettings] = useState({ baseUrl: 'https://api.openai.com/v1', model: 'gpt-image-2.5-sunburst' });
  const [confirmSettingsClose, setConfirmSettingsClose] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const settingsPanelRef = useRef<HTMLDivElement>(null);
  const [savingKey, setSavingKey] = useState(false);
  const [imageModel, setImageModel] = useState('gpt-image-2.5-sunburst');
  const [apiBaseUrl, setApiBaseUrl] = useState('https://api.openai.com/v1');
  const [availableModels, setAvailableModels] = useState(defaultImageModels);
  const [testingApi, setTestingApi] = useState(false);
  const [engine, setEngine] = useState<'api' | 'assistant'>('api');
  const [assistantMessage, setAssistantMessage] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const plateInputRef = useRef<HTMLInputElement>(null);
  const backdropInputRef = useRef<HTMLInputElement>(null);
  const processingControllers = useRef(new Map<string, AbortController>());
  const activeJobIds = useRef(new Set<string>());
  const batchActive = useRef(false);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const stopRequested = useRef(false);
  const activeMode = useMemo(
    () => modes.find((item) => item.id === mode) || modes[0],
    [mode],
  );
  const doneCount = jobs.filter((job) => job.status === 'done').length;
  const pendingCount = jobs.filter((job) => job.status !== 'done' && job.status !== 'processing').length;
  const running = jobs.some((job) => job.status === 'processing');
  const busy = running || batchProcessing || fusionProcessing || bundleProcessing;
  const averageProgress = jobs.length
    ? Math.round(jobs.reduce((sum, job) => sum + job.progress, 0) / jobs.length)
    : 0;
  const assistantPrompt = useMemo(
    () =>
      [
        `请处理我附上的菜品图片。处理模式：${activeMode.title}。`,
        `目标角度：${angle}；光线与白平衡优化强度：${strength}%；输出尺寸：${size}。原图菜品的纹理、颜色、油光和细节应尽量保持，不要过度锐化、提高局部对比、加重橙红色或制造塑料般的光泽。`,
        protectFood
          ? '必须保护菜品形态：保持菜品种类、食材身份、分量和原有摆盘关系。'
          : '允许根据商业菜品摄影效果适度调整摆盘。',
        plate
          ? '我还会附上标准盘参考图，请将菜品统一到该盘子，匹配盘型、材质、颜色、比例和透视。'
          : getContainerPreset(containerPreset).id !== 'original'
            ? `将菜品放入${getContainerPreset(containerPreset).name}，容器要求：${getContainerPreset(containerPreset).prompt}。仅保留此容器，不保留原容器。`
            : '保留并补全原图容器。',
        customInstruction ? `特殊定制要求：${customInstruction}` : '',
        '最终只保留完整的菜品与盘子，主体居中并留少量安全边距；输出真正带 Alpha 通道的透明背景 PNG。轮廓边缘必须干净自然并带柔和抗锯齿，不得出现黑边、红边、彩色描边、色溢、光晕、棋盘格像素或残留背景。不要桌面、背景、道具、文字、Logo、水印或外框。',
      ]
        .filter(Boolean)
        .join('\n'),
    [activeMode.title, angle, containerPreset, customInstruction, plate, protectFood, size, strength],
  );

  useEffect(() => {
    let saved: SavedProject[] = [];
    try {
      const value: unknown = JSON.parse(localStorage.getItem(PROJECT_INDEX_KEY) || '[]');
      if (!Array.isArray(value)) throw new Error('项目索引格式无效');
      saved = value.filter((item): item is SavedProject => Boolean(item && typeof item.id === 'string' && typeof item.name === 'string'));
    } catch {
      setAssistantMessage('项目列表读取失败，已打开新项目。原有图片数据仍保留在本机，请先备份 data 文件夹。');
    }
    const initial = saved[0] || { id: crypto.randomUUID(), name: '我的菜品项目', updatedAt: Date.now() };
    setProjects(saved.length ? saved : [initial]);
    setProjectId(initial.id);
    setProjectName(initial.name);
    void getProject(initial.id)
      .then((data) => {
        if (!data) return;
        setProjectType(data.projectType || 'single');
        setContainerPreset(getContainerPreset(data.mode === 'plate' && (!data.containerPreset || data.containerPreset === 'original') ? 'round-medium' : data.containerPreset || 'original').id);
        setFusionStyle(data.fusionStyle || 'new_plate');
        setFusionSelection(data.fusionSelection || []);
        setFusionMainId(data.fusionMainId || '');
        setFusionResult(data.fusionResult || '');
        setBundleSelection(data.bundleSelection || []);
        setBundleLayouts(data.bundleLayouts || {});
        setBundleMethod(data.bundleMethod || 'local');
        setBundlePlacement(data.bundlePlacement || 'manual');
        setBundleBackground(data.bundleBackground || 'cream');
        setCustomInstruction(data.customInstruction || '');
        setMode('material');
        setAngle(data.angle || '斜俯拍 45°');
        setSize(data.size || '1024 × 1024');
        setStrength(data.strength ?? 35);
        setProtectFood(data.protectFood ?? true);
        setJobs(data.jobs.map((job) => ({ ...job, name: job.name || job.file.name.replace(/\.[^.]+$/, ''), src: URL.createObjectURL(job.file), ...(job.status === 'processing' ? { status: 'error' as const, progress: 0, error: '上次处理已中断，请重新开始。' } : {}) })));
        setPlate(data.plate ? { ...data.plate, src: URL.createObjectURL(data.plate.file) } : null);
        setBackdrop(data.backdrop ? { ...data.backdrop, src: URL.createObjectURL(data.backdrop.file) } : null);
      })
      .catch(() => setAssistantMessage('无法读取当前项目，请刷新页面后重试。'))
      .finally(() => setProjectReady(true));
  }, []);

  useEffect(() => {
    if (!projectReady || !projectId) return;
    const timer = window.setTimeout(() => {
      const updatedAt = Date.now();
      setProjects((current) => {
        const next = [{ id: projectId, name: projectName || '未命名项目', updatedAt }, ...current.filter((item) => item.id !== projectId)];
        try { localStorage.setItem(PROJECT_INDEX_KEY, JSON.stringify(next)); }
        catch { setAssistantMessage('项目列表保存失败，请先导出成品并检查磁盘空间。'); }
        return next;
      });
      void putProject({ id: projectId, name: projectName || '未命名项目', updatedAt, projectType, containerPreset, fusionStyle, fusionSelection, fusionMainId, fusionResult, bundleSelection, bundleLayouts, bundleMethod, bundlePlacement, bundleBackground, customInstruction, mode, angle, size, strength, protectFood, jobs, plate, backdrop })
        .catch(() => setAssistantMessage('本地存储空间不足，项目可能无法完整保存。请先导出成品并清理较早项目。'));
    }, 500);
    return () => window.clearTimeout(timer);
  }, [angle, backdrop, bundleBackground, bundleLayouts, bundleMethod, bundlePlacement, bundleSelection, containerPreset, customInstruction, fusionMainId, fusionResult, fusionSelection, fusionStyle, jobs, mode, plate, projectId, projectName, projectReady, projectType, protectFood, size, strength]);

  useEffect(() => {
    fetch('/api/settings')
      .then((response) => readJson<SettingsResponse>(response))
      .then((data) => {
        setApiConfigured(Boolean(data.configured));
        if (data.error) {
          setApiMessageStatus('error');
          setApiSettingMessage(data.error);
        }
        setSavedApiSettings({ baseUrl: data.baseUrl || 'https://api.openai.com/v1', model: data.model || 'gpt-image-2.5-sunburst' });
        if (data.baseUrl) setApiBaseUrl(data.baseUrl);
        if (data.model) {
          setImageModel(data.model);
          if (!defaultImageModels.some((item) => item.id === data.model))
            setAvailableModels([
              { id: data.model, name: data.model, detail: '已保存' },
              ...defaultImageModels,
            ]);
        }
      })
      .catch(() => undefined);
  }, []);


  useEffect(() => {
    if (!settingsOpen && !previewImage) return;
    function closeOnEscape(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setPreviewImage(null);
      }
    }
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [previewImage, settingsOpen]);

  useEffect(() => {
    if (!settingsOpen) return;
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    settingsPanelRef.current?.focus();
    return () => {
      document.body.style.overflow = overflow;
      previous?.focus();
    };
  }, [settingsOpen]);

  function requestSettingsClose() {
    if (savingKey || testingApi) return;
    if (apiKeyInput.trim() || apiBaseUrl !== savedApiSettings.baseUrl || imageModel !== savedApiSettings.model) {
      setConfirmSettingsClose(true);
    } else setSettingsOpen(false);
  }

  useEffect(() => {
    if (!assistantMessage) return;
    const timer = window.setTimeout(() => setAssistantMessage(''), 4500);
    return () => window.clearTimeout(timer);
  }, [assistantMessage]);

  useEffect(() => {
    setBundleResult('');
  }, [bundleSelection, bundleLayouts, bundleMethod, bundlePlacement, bundleBackground, backdrop, size, angle, strength, customInstruction, imageModel]);

  useEffect(() => () => {
    if (bundleResult.startsWith('blob:')) URL.revokeObjectURL(bundleResult);
  }, [bundleResult]);

  useEffect(() => {
    const context = (document as Document & { modelContext?: WebMcpContext })
      .modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    void Promise.resolve(
      context.registerTool(
        {
          name: 'configure_food_image_processing',
          title: '配置菜品图处理',
          description:
            '设置当前菜品图处理模式、目标角度和优化强度，并同步更新可见界面。',
          inputSchema: {
            type: 'object',
            properties: {
              mode: { type: 'string', enum: modes.map((item) => item.id) },
              angle: { type: 'string', enum: angles },
              strength: { type: 'number', minimum: 20, maximum: 100 },
            },
            additionalProperties: false,
          },
          annotations: { readOnlyHint: false, untrustedContentHint: false },
          execute(input: unknown) {
            const value = input as {
              mode?: string;
              angle?: string;
              strength?: number;
            };
            if (value.mode && modes.some((item) => item.id === value.mode))
              setMode(value.mode);
            if (value.mode === 'plate')
              setContainerPreset((current) => current === 'original' ? 'round-medium' : current);
            if (value.angle && angles.includes(value.angle))
              setAngle(value.angle);
            if (
              typeof value.strength === 'number' &&
              value.strength >= 20 &&
              value.strength <= 100
            )
              setStrength(value.strength);
            return {
              configured: true,
              mode: value.mode,
              angle: value.angle,
              strength: value.strength,
            };
          },
        },
        { signal: lifecycle.signal },
      ),
    ).catch(() => undefined);
    return () => lifecycle.abort();
  }, []);

  useEffect(() => {
    function handlePaste(event: ClipboardEvent) {
      const target = event.target;
      if (target instanceof HTMLElement && target.closest('input, textarea, [contenteditable="true"], [role="textbox"]')) return;
      const files = Array.from(event.clipboardData?.items || [])
        .filter((item) => item.type.startsWith('image/'))
        .map((item) => item.getAsFile())
        .filter((file): file is File => Boolean(file));
      if (files.length) {
        event.preventDefault();
        void addFiles(files);
      }
    }
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, []);

  async function addFiles(list: FileList | File[]) {
    const images = Array.from(list).filter((file) =>
      file.type.startsWith('image/'),
    );
    const optimized = await Promise.all(
      images.map(async (file) => {
        try {
          return await optimizeInput(file);
        } catch {
          return file;
        }
      }),
    );
    setJobs((current) => [
      ...current,
      ...optimized.map((file) => ({
        id: crypto.randomUUID(),
        file,
        name: file.name.replace(/\.[^.]+$/, ''),
        src: URL.createObjectURL(file),
        status: 'ready' as const,
        progress: 0,
      })),
    ]);
  }
  async function addFilesAndArchives(list: FileList | File[]) {
    const files = Array.from(list);
    const regularImages = files.filter((file) =>
      file.type.startsWith('image/'),
    );
    const archives = files.filter(
      (file) =>
        file.type === 'application/zip' ||
        file.name.toLowerCase().endsWith('.zip'),
    );
    if (regularImages.length) await addFiles(regularImages);
    for (const archive of archives) {
      try {
        const zip = await JSZip.loadAsync(archive);
        const extracted: File[] = [];
        for (const entry of Object.values(zip.files)) {
          if (entry.dir || !/\.(png|jpe?g|webp|gif)$/i.test(entry.name))
            continue;
          const blob = await entry.async('blob');
          const name = entry.name.split('/').pop() || entry.name;
          extracted.push(
            new File([blob], name, { type: imageMimeFromName(name) }),
          );
        }
        if (extracted.length) await addFiles(extracted);
      } catch {
        setAssistantMessage(`无法读取压缩包：${archive.name}`);
      }
    }
  }
  function onDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setDragging(false);
    void addFilesAndArchives(event.dataTransfer.files);
  }
  async function pasteFromClipboard() {
    try {
      const items = await navigator.clipboard.read();
      const files: File[] = [];
      for (const item of items) {
        const type = item.types.find((value) => value.startsWith('image/'));
        if (!type) continue;
        const blob = await item.getType(type);
        files.push(
          new File(
            [blob],
            `粘贴图片-${Date.now()}.${type.split('/')[1] || 'png'}`,
            { type },
          ),
        );
      }
      if (files.length) void addFiles(files);
    } catch {
      window.alert('请先复制一张图片，然后在页面中按 Ctrl+V。');
    }
  }
  async function choosePlate(event: ChangeEvent<HTMLInputElement>) {
    const source = event.target.files?.[0];
    if (source) {
      const file = await optimizeInput(source).catch(() => source);
      setPlate({ file, src: URL.createObjectURL(file) });
      setContainerListOpen(false);
      setFusionResult('');
    }
    event.target.value = '';
  }
  async function chooseBackdrop(event: ChangeEvent<HTMLInputElement>) {
    const source = event.target.files?.[0];
    if (source) {
      const file = await optimizeInput(source).catch(() => source);
      setBackdrop({ file, src: URL.createObjectURL(file) });
    }
    event.target.value = '';
  }
  async function persistCurrentProject() {
    if (!projectReady || !projectId) return true;
    try {
      await putProject({ id: projectId, name: projectName || '未命名项目', updatedAt: Date.now(), projectType, containerPreset, fusionStyle, fusionSelection, fusionMainId, fusionResult, bundleSelection, bundleLayouts, bundleMethod, bundlePlacement, bundleBackground, customInstruction, mode, angle, size, strength, protectFood, jobs, plate, backdrop });
      return true;
    } catch {
      setAssistantMessage('当前项目保存失败，已取消切换。请先导出成品并清理较早项目。');
      return false;
    }
  }
  async function switchProject(id: string, saveCurrent = true) {
    if (id === projectId) return;
    if (busy) { setAssistantMessage('请先等待当前处理完成，或终止处理后再切换项目。'); return; }
    if (saveCurrent && !(await persistCurrentProject())) return;
    setProjectReady(false);
    let data: ProjectData | undefined;
    try {
      data = await getProject(id);
    } catch {
      setAssistantMessage('无法打开所选项目，请重试。');
      setProjectReady(true);
      return;
    }
    const summary = projects.find((item) => item.id === id);
    setProjectId(id);
    setProjectName(data?.name || summary?.name || '未命名项目');
    setProjectType(data?.projectType || 'single');
    setContainerPreset(getContainerPreset(data?.mode === 'plate' && (!data.containerPreset || data.containerPreset === 'original') ? 'round-medium' : data?.containerPreset || 'original').id);
    setContainerListOpen(false);
    setFusionStyle(data?.fusionStyle || 'new_plate');
    setFusionSelection(data?.fusionSelection || []);
    setFusionMainId(data?.fusionMainId || '');
    setFusionResult(data?.fusionResult || '');
    setBundleSelection(data?.bundleSelection || []);
    setBundleLayouts(data?.bundleLayouts || {});
    setBundleMethod(data?.bundleMethod || 'local');
    setBundlePlacement(data?.bundlePlacement || 'manual');
    setBundleBackground(data?.bundleBackground || 'cream');
    setCustomInstruction(data?.customInstruction || '');
    setMode('material');
    setAngle(data?.angle || '斜俯拍 45°');
    setSize(data?.size || '1024 × 1024');
    setStrength(data?.strength ?? 35);
    setProtectFood(data?.protectFood ?? true);
    setBundleResult('');
    setJobs(data?.jobs.map((job) => ({ ...job, name: job.name || job.file.name.replace(/\.[^.]+$/, ''), src: URL.createObjectURL(job.file), ...(job.status === 'processing' ? { status: 'error' as const, progress: 0, error: '上次处理已中断，请重新开始。' } : {}) })) || []);
    setPlate(data?.plate ? { ...data.plate, src: URL.createObjectURL(data.plate.file) } : null);
    setBackdrop(data?.backdrop ? { ...data.backdrop, src: URL.createObjectURL(data.backdrop.file) } : null);
    setProjectReady(true);
  }
  async function createProject() {
    if (busy) { setAssistantMessage('请先等待当前处理完成，或终止处理后再新建项目。'); return; }
    if (!(await persistCurrentProject())) return;
    const item = { id: crypto.randomUUID(), name: `菜品项目 ${projects.length + 1}`, updatedAt: Date.now() };
    setProjects((current) => [item, ...current]);
    setProjectId(item.id);
    setProjectName(item.name);
    setProjectType('single');
    setContainerPreset('original');
    setContainerListOpen(false);
    setFusionStyle('new_plate');
    setFusionSelection([]);
    setFusionMainId('');
    setFusionResult('');
    setCustomInstruction('');
    setMode('material');
    setAngle('斜俯拍 45°');
    setSize('1024 × 1024');
    setStrength(35);
    setProtectFood(true);
    setBundleSelection([]);
    setBundleLayouts({});
    setBundleMethod('local');
    setBundlePlacement('manual');
    setBundleBackground('cream');
    setBundleResult('');
    setJobs([]);
    setPlate(null);
    setBackdrop(null);
    setProjectReady(true);
  }
  async function removeCurrentProject() {
    if (busy) { setAssistantMessage('请先等待当前处理完成，或终止处理后再删除项目。'); return; }
    if (!window.confirm(`确定删除项目“${projectName}”吗？项目中的图片和设置将从本机移除。`)) return;
    if (projects.length <= 1) {
      setJobs([]);
      setPlate(null);
      setBackdrop(null);
      setProjectName('我的菜品项目');
      setProjectType('single');
      setContainerPreset('original');
      setFusionStyle('new_plate');
      setFusionSelection([]);
      setFusionMainId('');
      setFusionResult('');
      setCustomInstruction('');
      setMode('material');
      setAngle('斜俯拍 45°');
      setSize('1024 × 1024');
      setStrength(35);
      setProtectFood(true);
      setBundleSelection([]);
      setBundleLayouts({});
      setBundleResult('');
      return;
    }
    const remaining = projects.filter((item) => item.id !== projectId);
    await deleteProjectRecord(projectId);
    setProjects(remaining);
    localStorage.setItem(PROJECT_INDEX_KEY, JSON.stringify(remaining));
    await switchProject(remaining[0].id, false);
  }
  function clearJobs() {
    if (!jobs.length || !window.confirm(`确定清空当前项目中的 ${jobs.length} 张图片吗？`)) return;
    jobs.forEach((job) => URL.revokeObjectURL(job.src));
    setJobs([]);
    setBundleSelection([]);
    setBundleLayouts({});
    setBundleResult('');
    setFusionSelection([]);
    setFusionMainId('');
    setFusionResult('');
  }
  function updateJob(id: string, patch: Partial<FoodJob>) {
    setJobs((current) =>
      current.map((job) => (job.id === id ? { ...job, ...patch } : job)),
    );
  }

  async function processOne(job: FoodJob) {
    if (activeJobIds.current.has(job.id)) return;
    activeJobIds.current.add(job.id);
    updateJob(job.id, { status: 'processing', progress: 15, error: undefined });
    const timer = window.setInterval(
      () =>
        setJobs((current) =>
          current.map((item) =>
            item.id === job.id && item.status === 'processing'
              ? { ...item, progress: Math.min(item.progress + 4, 88) }
              : item,
          ),
        ),
      700,
    );
    try {
        if (stopRequested.current) throw new Error('已手动终止');
        const controller = new AbortController();
        processingControllers.current.set(job.id, controller);
        let timedOut = false;
        const timeout = window.setTimeout(() => {
          timedOut = true;
          controller.abort();
        }, PROCESS_TIMEOUT_MS);
        try {
          const form = new FormData();
          form.append('image', job.file);
          if (plate) form.append('plate', plate.file);
          form.append('mode', 'material');
          form.append('containerPreset', containerPreset);
          form.append('angle', angle);
          form.append('size', size.replaceAll(' ', '').replace('×', 'x'));
          form.append('strength', String(strength));
          form.append('protectFood', String(protectFood));
          form.append('customInstruction', customInstruction);
          form.append('model', imageModel);
          const response = await fetch('/api/process', { method: 'POST', body: form, signal: controller.signal });
          const contentType = response.headers.get('content-type') || '';
          const data: ProcessResponse = contentType.includes('application/json') ? await readJson<ProcessResponse>(response) : { error: await response.text() };
          if (!response.ok) {
            if (response.status === 413) throw new Error('图片体积过大，请尝试缩小图片后重新上传。');
            throw new Error(data.error || `处理失败（${response.status}）`);
          }
          if (!data.image) throw new Error('图像服务没有返回图片');
          const transparentBlob = await ensureTransparentPng(await fetch(data.image, { signal: controller.signal }).then((result) => result.blob()), true);
          const transparentImage = await blobToDataUrl(transparentBlob);
          updateJob(job.id, { status: 'done', progress: 100, result: transparentImage, error: undefined });
          return;
        } catch (error) {
          if (stopRequested.current) throw new Error('已手动终止');
          throw new Error(timedOut ? '本张图片等待超过十分钟。请先确认服务端任务状态，避免重复提交。' : error instanceof Error ? error.message : '处理失败');
        } finally {
          window.clearTimeout(timeout);
          processingControllers.current.delete(job.id);
        }
    } catch (error) {
      updateJob(job.id, {
        status: 'error',
        progress: 0,
        error: error instanceof Error ? error.message : '处理失败',
      });
    } finally {
      window.clearInterval(timer);
      activeJobIds.current.delete(job.id);
    }
  }
  async function processSingle(job: FoodJob) {
    if (batchActive.current || fusionProcessing || bundleProcessing || activeJobIds.current.has(job.id)) return;
    if (!apiConfigured) { setSettingsOpen(true); return; }
    if (job.result && !window.confirm('重新处理会再次调用图像 API。继续吗？')) return;
    stopRequested.current = false;
    await processOne(job);
  }
  async function processAll() {
    if (batchActive.current || activeJobIds.current.size || fusionProcessing || bundleProcessing) return;
    if (!apiConfigured) { setSettingsOpen(true); return; }
    batchActive.current = true;
    setBatchProcessing(true);
    stopRequested.current = false;
    try {
    for (const job of jobs.filter(
      (item) => item.status !== 'processing' && item.status !== 'done',
    )) {
      if (stopRequested.current) break;
      await processOne(job);
    }
    } finally {
      batchActive.current = false;
      setBatchProcessing(false);
    }
  }
  function stopProcessing() {
    stopRequested.current = true;
    processingControllers.current.forEach((controller) => controller.abort());
    processingControllers.current.clear();
    setJobs((current) => current.map((job) => job.status === 'processing' ? { ...job, status: 'error', progress: 0, error: '已手动终止，可重新开始处理。' } : job));
  }
  async function transparentResultBlob(job: FoodJob) {
    if (!job.result) throw new Error('没有可用的处理结果');
    return ensureTransparentPng(await fetch(job.result).then((response) => response.blob()));
  }
  async function repairTransparency(job: FoodJob) {
    try {
      const blob = await transparentResultBlob(job);
      updateJob(job.id, { result: await blobToDataUrl(blob), error: undefined });
      setAssistantMessage(`${job.name || '菜品'}的透明边缘已清理。`);
    } catch (error) {
      setAssistantMessage(error instanceof Error ? error.message : '透明背景修复失败');
    }
  }
  async function download(job: FoodJob) {
    if (!job.result) return;
    try {
      const blob = await transparentResultBlob(job);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${job.name || '菜品'}-透明优化.png`;
      a.click();
      URL.revokeObjectURL(url);
      setAssistantMessage(`${job.name || '菜品'}已下载。`);
    } catch (error) {
      setAssistantMessage(error instanceof Error ? error.message : '图片下载失败');
    }
  }
  async function makeDisplayBlob(job: FoodJob) {
    if (!job.result || !backdrop) throw new Error('请先处理菜品并添加展示底图');
    const [bg, food] = await Promise.all([
      createImageBitmap(await fetch(backdrop.src).then((response) => response.blob())),
      createImageBitmap(await fetch(job.result).then((response) => response.blob())),
    ]);
    const [width, height] = size.replaceAll(' ', '').split('×').map(Number);
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('浏览器无法创建展示图');
    const bgScale = Math.max(width / bg.width, height / bg.height);
    context.drawImage(bg, (width - bg.width * bgScale) / 2, (height - bg.height * bgScale) / 2, bg.width * bgScale, bg.height * bgScale);
    const foodScale = Math.min((width * 0.86) / food.width, (height * 0.86) / food.height);
    context.drawImage(food, (width - food.width * foodScale) / 2, (height - food.height * foodScale) / 2, food.width * foodScale, food.height * foodScale);
    bg.close();
    food.close();
    return await new Promise<Blob>((resolve, reject) =>
      canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('合成失败')), 'image/png'),
    );
  }
  async function exportDisplay(job: FoodJob) {
    try {
      const blob = await makeDisplayBlob(job);
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `${job.name || '菜品'}-展示图.png`;
      anchor.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      setAssistantMessage(error instanceof Error ? error.message : '展示图导出失败');
    }
  }
  async function copyDisplay(job: FoodJob) {
    try {
      const blob = await makeDisplayBlob(job);
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      setAssistantMessage(`${job.name || '菜品'}的展示图已复制。`);
    } catch (error) {
      setAssistantMessage(error instanceof Error ? error.message : '复制失败');
    }
  }
  function selectedBundleJobs() {
    return jobs.filter((job) => bundleSelection.includes(job.id) && job.result);
  }
  function bundleLayoutFor(job: FoodJob, index: number, total: number) {
    return bundleLayouts[job.id] || defaultBundleLayout(index, total);
  }
  function updateBundleLayout(id: string, patch: Partial<BundleLayout>) {
    const selected = selectedBundleJobs();
    const index = selected.findIndex((job) => job.id === id);
    if (index < 0) return;
    setBundleLayouts((current) => ({ ...current, [id]: { ...(current[id] || defaultBundleLayout(index, selected.length)), ...patch } }));
  }
  function resetBundleLayout() {
    setBundleLayouts({});
    setAssistantMessage('已恢复合理排版，可继续手动调整。');
  }
  async function makeLocalBundleBlob(scene = false) {
    const selected = selectedBundleJobs();
    if (selected.length < 2) throw new Error('请至少选择 2 张已处理菜品图');
    const [width, height] = size.replaceAll(' ', '').split('×').map(Number);
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('浏览器无法创建套餐图');
    if (backdrop) {
      const bg = await createImageBitmap(await fetch(backdrop.src).then((response) => response.blob()));
      const scale = Math.max(width / bg.width, height / bg.height);
      context.drawImage(bg, (width - bg.width * scale) / 2, (height - bg.height * scale) / 2, bg.width * scale, bg.height * scale);
      bg.close();
    } else if (scene) {
      const gradient = context.createLinearGradient(0, 0, width, height);
      if (bundleBackground === 'slate') {
        gradient.addColorStop(0, '#46535b');
        gradient.addColorStop(1, '#202a30');
      } else {
        gradient.addColorStop(0, '#f5f0e7');
        gradient.addColorStop(1, '#d9d0c2');
      }
      context.fillStyle = gradient;
      context.fillRect(0, 0, width, height);
    }
    const ordered = selected.map((job, index) => ({ job, layout: bundleLayoutFor(job, index, selected.length) })).sort((a, b) => a.layout.order - b.layout.order);
    for (const { job, layout } of ordered) {
      const food = await createImageBitmap(await fetch(job.result!).then((response) => response.blob()));
      const drawWidth = width * layout.scale;
      const drawHeight = drawWidth * food.height / food.width;
      context.drawImage(food, width * layout.x - drawWidth / 2, height * layout.y - drawHeight / 2, drawWidth, drawHeight);
      food.close();
    }
    return await new Promise<Blob>((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('套餐合成失败')), 'image/png'));
  }
  async function makeOpaqueSceneBlob(blob: Blob) {
    const image = await createImageBitmap(blob);
    const canvas = document.createElement('canvas');
    canvas.width = image.width;
    canvas.height = image.height;
    const context = canvas.getContext('2d');
    if (!context) { image.close(); throw new Error('浏览器无法创建场景图'); }
    if (backdrop) {
      const background = await createImageBitmap(await fetch(backdrop.src).then((response) => response.blob()));
      const scale = Math.max(canvas.width / background.width, canvas.height / background.height);
      context.drawImage(background, (canvas.width - background.width * scale) / 2, (canvas.height - background.height * scale) / 2, background.width * scale, background.height * scale);
      background.close();
    } else {
      const gradient = context.createLinearGradient(0, 0, canvas.width, canvas.height);
      if (bundleBackground === 'slate') { gradient.addColorStop(0, '#46535b'); gradient.addColorStop(1, '#202a30'); }
      else { gradient.addColorStop(0, '#f5f0e7'); gradient.addColorStop(1, '#d9d0c2'); }
      context.fillStyle = gradient;
      context.fillRect(0, 0, canvas.width, canvas.height);
    }
    context.drawImage(image, 0, 0);
    image.close();
    return await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error('场景图导出失败')), 'image/png'));
  }
  async function buildBundle() {
    const selected = selectedBundleJobs();
    if (selected.length < 2) {
      setAssistantMessage('请至少选择 2 张已处理菜品图。');
      return;
    }
    setBundleProcessing(true);
    setAssistantMessage('');
    try {
      const blob = bundleMethod === 'local' || bundlePlacement === 'manual'
        ? await makeLocalBundleBlob(bundleMethod === 'ai')
        : await (async () => {
            const form = new FormData();
            for (const job of selected) {
              const image = await fetch(job.result!).then((response) => response.blob());
              form.append('image', image, `${job.name}.png`);
            }
            if (backdrop) form.append('backdrop', backdrop.file);
            form.append('mode', 'bundle');
            form.append('sceneStyle', bundleBackground);
            form.append('angle', angle);
            form.append('size', size.replaceAll(' ', '').replace('×', 'x'));
            form.append('strength', String(strength));
            form.append('protectFood', 'true');
            form.append('customInstruction', customInstruction);
            form.append('model', imageModel);
            const response = await fetch('/api/process', { method: 'POST', body: form });
            const data = await readJson<ProcessResponse>(response);
            if (!response.ok) throw new Error(data.error || 'AI 套餐合成失败');
            if (!data.image) throw new Error('图像服务没有返回套餐图片');
            const imageBlob = await fetch(data.image).then((result) => result.blob());
            return await makeOpaqueSceneBlob(imageBlob);
          })();
      setBundleResult(URL.createObjectURL(blob));
      setAssistantMessage('套餐展示图已生成。');
    } catch (error) {
      setAssistantMessage(error instanceof Error ? error.message : '套餐合成失败');
    } finally {
      setBundleProcessing(false);
    }
  }
  async function buildFusion() {
    const selected = jobs.filter((job) => fusionSelection.includes(job.id));
    if (selected.length < 2 || selected.length > 8) {
      setFusionError('请选择 2–8 道菜参与融合。');
      return;
    }
    const main = selected.find((job) => job.id === fusionMainId) || selected[0];
    const ordered = fusionStyle === 'into_main'
      ? [main, ...selected.filter((job) => job.id !== main.id)]
      : selected;
    setFusionProcessing(true);
    setFusionError('');
    setFusionResult('');
    try {
      const form = new FormData();
      const sources = await Promise.all(ordered.map((job) => optimizeInput(job.file, 2 * 1024 * 1024, 1600)));
      if (sources.reduce((total, file) => total + file.size, 0) + (fusionStyle === 'new_plate' ? plate?.file.size || 0 : 0) > 22 * 1024 * 1024)
        throw new Error('所选图片总大小仍超过 22 MB，请减少图片数量或使用更小的原图。');
      for (const file of sources) form.append('image', file, file.name);
      if (fusionStyle === 'new_plate' && plate) form.append('plate', plate.file, plate.file.name);
      form.append('mode', 'fusion');
      form.append('fusionStyle', fusionStyle);
      form.append('containerPreset', fusionStyle === 'new_plate' && containerPreset === 'original' ? 'round-medium' : containerPreset);
      form.append('angle', angle);
      form.append('size', size.replaceAll(' ', '').replace('×', 'x'));
      form.append('strength', String(strength));
      form.append('protectFood', 'true');
      form.append('customInstruction', customInstruction);
      form.append('model', imageModel);
      const response = await fetch('/api/process', { method: 'POST', body: form });
      const data = await readJson<ProcessResponse>(response);
      if (!response.ok) throw new Error(data.error || '融合失败');
      if (!data.image) throw new Error('图像服务没有返回融合图');
      const blob = await ensureTransparentPng(await fetch(data.image).then((result) => result.blob()), true);
      setFusionResult(await blobToDataUrl(blob));
    } catch (error) {
      setFusionError(error instanceof Error ? error.message : '融合失败');
    } finally {
      setFusionProcessing(false);
    }
  }
  function downloadFusion() {
    if (!fusionResult) return;
    const anchor = document.createElement('a');
    anchor.href = fusionResult;
    anchor.download = `${projectName || '菜品'}-融合菜品.png`;
    anchor.click();
  }
  function downloadBundle() {
    if (!bundleResult) return;
    const anchor = document.createElement('a');
    anchor.href = bundleResult;
    anchor.download = `${projectName || '套餐'}-组合展示图.png`;
    anchor.click();
  }
  async function copyBundle() {
    if (!bundleResult) return;
    try {
      const blob = await fetch(bundleResult).then((response) => response.blob());
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      setAssistantMessage('套餐展示图已复制。');
    } catch {
      setAssistantMessage('套餐展示图复制失败，请改用导出 PNG。');
    }
  }
  async function repairBundleTransparency() {
    if (!bundleResult) return;
    try {
      const blob = await ensureTransparentPng(await fetch(bundleResult).then((response) => response.blob()));
      setBundleResult(URL.createObjectURL(blob));
      setAssistantMessage('套餐容器的透明边缘已清理。');
    } catch (error) {
      setAssistantMessage(error instanceof Error ? error.message : '套餐边缘修复失败');
    }
  }
  async function copyResult(job: FoodJob) {
    if (!job.result) return;
    try {
      const png = await transparentResultBlob(job);
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': png }),
      ]);
      setAssistantMessage(`${job.file.name} 的成品已复制。`);
    } catch {
      setAssistantMessage('当前浏览器无法复制图片，请使用下载按钮。');
    }
  }
  async function exportCompletedZip() {
    const completed = jobs.filter((job) => job.result);
    if (!completed.length) return;
    const zip = new JSZip();
    for (const job of completed) {
      const blob = await transparentResultBlob(job);
      zip.file(
        `${job.name || '菜品'}-透明优化.png`,
        blob,
      );
    }
    const output = await zip.generateAsync({
      type: 'blob',
      compression: 'DEFLATE',
    });
    const url = URL.createObjectURL(output);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `菜品图成品-${new Date().toISOString().slice(0, 10)}.zip`;
    anchor.click();
    URL.revokeObjectURL(url);
  }
  async function saveApiKey() {
    setApiMessageStatus('error');
    const value = apiKeyInput.trim();
    if (!apiConfigured && value.length < 8) {
      setApiSettingMessage('请输入有效的 API 密钥。');
      return;
    }
    if (value && value.length < 8) {
      setApiSettingMessage('API 密钥格式不正确。');
      return;
    }
    setSavingKey(true);
    setApiSettingMessage('');
    try {
      const response = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: value || undefined,
          model: imageModel,
          baseUrl: apiBaseUrl,
        }),
      });
      const data = await readJson<SettingsResponse>(response);
      if (!response.ok) throw new Error(data.error || '保存失败');
      setApiConfigured(Boolean(data.configured));
      setApiKeyInput('');
      setSavedApiSettings({ baseUrl: data.baseUrl || apiBaseUrl, model: data.model || imageModel });
      if (data.baseUrl) setApiBaseUrl(data.baseUrl);
      setConfirmSettingsClose(false);
      setApiMessageStatus('success');
      setApiSettingMessage('设置已保存到本机，重新打开后自动读取。');
    } catch (error) {
      setApiSettingMessage(error instanceof Error ? error.message : '保存失败');
    } finally {
      setSavingKey(false);
    }
  }
  async function clearApiKey() {
    if (savingKey || testingApi) return;
    setSavingKey(true);
    setApiMessageStatus('error');
    try {
      const response = await fetch('/api/settings', { method: 'DELETE' });
      const data = await readJson<SettingsResponse>(response);
      if (!response.ok) throw new Error(data.error || '清除失败');
      setApiConfigured(false);
      setApiKeyInput('');
      setApiMessageStatus('success');
      setApiSettingMessage('已从本地配置文件清除密钥。');
    } catch (error) {
      setApiSettingMessage(error instanceof Error ? error.message : '清除失败');
    } finally {
      setSavingKey(false);
    }
  }
  async function testApiConnection() {
    setApiMessageStatus('error');
    const value = apiKeyInput.trim();
    if (!apiConfigured && value.length < 8) {
      setApiSettingMessage('请先填写有效的 API 密钥。');
      return;
    }
    setTestingApi(true);
    setApiMessageStatus('info');
    setApiSettingMessage('正在连接并读取模型列表…');
    try {
      const response = await fetch('/api/settings', {
        method: 'POST',
        signal: AbortSignal.timeout(25000),
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'test',
          apiKey: value || undefined,
          baseUrl: apiBaseUrl,
        }),
      });
      const data = await readJson<SettingsResponse>(response);
      if (!response.ok) throw new Error(data.error || '连接失败');
      const models = (data.models || []).map((id) => ({
        id,
        name: id,
        detail: 'API 返回',
      }));
      setAvailableModels(models.length ? models : defaultImageModels);
      setApiSettingMessage(
        `连接成功，读取到 ${models.length} 个模型。请选择支持图片编辑的模型。`,
      );
      setApiMessageStatus('success');
    } catch (error) {
      setApiMessageStatus('error');
      setApiSettingMessage(error instanceof Error ? error.message : '连接失败');
    } finally {
      setTestingApi(false);
    }
  }
  async function copyAssistantPrompt() {
    try {
      await navigator.clipboard.writeText(assistantPrompt);
      setAssistantMessage('处理指令已复制，请粘贴到你使用的 AI 图片编辑工具中。');
    } catch {
      setAssistantMessage('无法自动复制，请允许浏览器访问剪贴板。');
    }
  }
  async function copyFirstImageForAssistant() {
    const job = jobs[0];
    if (!job) return;
    try {
      const source = await fetch(job.src).then((response) => response.blob());
      const bitmap = await createImageBitmap(source);
      const canvas = document.createElement('canvas');
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      canvas.getContext('2d')?.drawImage(bitmap, 0, 0);
      bitmap.close();
      const png = await new Promise<Blob | null>((resolve) =>
        canvas.toBlob(resolve, 'image/png'),
      );
      if (!png) throw new Error('转换失败');
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': png }),
      ]);
      setAssistantMessage(
        '第一张菜品图已复制，请先粘贴到 AI 工具；随后再复制处理指令。',
      );
    } catch {
      setAssistantMessage('当前浏览器无法复制图片，可直接把原图拖入你使用的 AI 工具。');
    }
  }

  return (
    <main className="min-h-screen bg-[#f1f1ed] text-[#171815]">
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-black/10 bg-[#f7f7f3]/92 px-5 backdrop-blur-xl lg:px-8">
        <div className="flex items-center gap-3">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-[#d9ff43] shadow-[inset_0_0_0_1px_rgba(0,0,0,.12)]">
            <Utensils className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-baseline gap-2 whitespace-nowrap">
              <h1 className="text-[17px] font-semibold tracking-[-.02em]">
                盘上造物
              </h1>
              <span className="text-[11px] font-normal text-black/45">寸灰</span>
            </div>
            <p className="text-[11px] tracking-[.12em] text-black/45">
              菜品图像工作台
            </p>
          </div>
        </div>
        <div className="flex min-w-0 items-center gap-2">
          <FolderOpen className="hidden h-4 w-4 text-black/40 md:block" />
          <select aria-label="选择项目" value={projectId} onChange={(event) => void switchProject(event.target.value)} className="hidden h-9 max-w-44 rounded-xl border border-black/10 bg-white px-2 text-sm md:block">
            {projects.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
          </select>
          <Button variant="outline" size="sm" disabled={busy} onClick={() => void createProject()} className="hidden rounded-xl bg-white md:inline-flex"><Plus className="h-4 w-4" />新项目</Button>
          <span className="hidden text-xs text-black/45 xl:inline">自带 API · 本地版</span>
          <button
            onClick={() => setSettingsOpen(true)}
            className="hidden items-center gap-2 rounded-full border border-black/10 bg-white px-3 py-1.5 text-xs text-black/55 sm:flex"
          >
            <span
              className={`h-2 w-2 rounded-full ${apiConfigured ? 'bg-[#79b900]' : 'bg-amber-500'}`}
            />
            {apiConfigured ? 'API 已配置' : '设置 API'}
          </button>
          <Button
            aria-label="设置"
            variant="ghost"
            size="icon"
            onClick={() => setSettingsOpen(true)}
            className="rounded-full"
          >
            <Settings2 className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1500px] grid-cols-1 gap-4 p-4 md:grid-cols-[250px_minmax(0,1fr)] lg:grid-cols-[286px_minmax(0,1fr)_310px] lg:p-6">
        <aside className="order-2 rounded-[24px] border border-black/10 bg-[#fafaf7] p-4 md:order-1 lg:min-h-[calc(100vh-112px)]">
          <div className="mb-5 rounded-2xl border border-black/10 bg-white p-3">
            <div className="mb-2 flex items-center justify-between"><span className="text-xs font-medium text-black/45">当前项目</span><button disabled={busy} onClick={() => void removeCurrentProject()} className="text-xs text-red-500 disabled:opacity-40">删除</button></div>
            <input value={projectName} onChange={(event) => setProjectName(event.target.value)} className="h-10 w-full rounded-xl bg-black/[.04] px-3 text-sm font-semibold outline-none focus:ring-1 focus:ring-black/20" aria-label="项目名称" />
            <div className="mt-2 grid grid-cols-3 gap-1 rounded-xl bg-black/[.05] p-1">
              <button onClick={() => { setProjectType('single'); setBundleResult(''); }} className={`whitespace-nowrap rounded-lg px-1.5 py-2 text-xs font-medium ${projectType === 'single' ? 'bg-white shadow-sm' : 'text-black/45'}`}>单菜品</button>
              <button onClick={() => setProjectType('bundle')} className={`whitespace-nowrap rounded-lg px-1.5 py-2 text-xs font-medium ${projectType === 'bundle' ? 'bg-white shadow-sm' : 'text-black/45'}`}>套餐</button>
              <button onClick={() => setProjectType('fusion')} className={`whitespace-nowrap rounded-lg px-1.5 py-2 text-xs font-medium ${projectType === 'fusion' ? 'bg-white shadow-sm' : 'text-black/45'}`}>菜品融合</button>
            </div>
            <div className="mt-2 flex gap-2 md:hidden">
              <select value={projectId} onChange={(event) => void switchProject(event.target.value)} className="min-w-0 flex-1 rounded-lg border px-2 text-xs">{projects.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select>
              <button disabled={busy} onClick={() => void createProject()} className="rounded-lg bg-black px-3 py-2 text-xs text-white disabled:opacity-40">新建</button>
            </div>
          </div>
          <div className="mb-4 flex items-center justify-between px-1">
            <h2 className="text-sm font-semibold">处理模式</h2>
            <span className="text-xs text-black/40">抠图 · 优化 · 更换容器</span>
          </div>
          <div className="space-y-2">
            <button
              onClick={() => setMode('material')}
              className="flex w-full items-center gap-3 rounded-2xl border border-[#b9df2c] bg-[#eaff91] p-3 text-left shadow-[0_5px_18px_rgba(130,170,0,.12)]"
            >
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#171815] text-[#d9ff43]"><Sparkles className="h-[18px] w-[18px]" /></span>
              <span className="min-w-0 flex-1"><span className="block text-sm font-semibold">素材处理</span><span className="mt-0.5 block text-xs text-black/45">优化菜品、选择容器并输出透明素材</span></span>
              <Check className="h-4 w-4" />
            </button>
          </div>
          <div className="my-5 h-px bg-black/8" />
          <div className="mb-3 flex items-center justify-between px-1">
            <h2 className="text-sm font-semibold">默认容器</h2>
            {plate && (
              <button
                onClick={() => { setPlate(null); setFusionResult(''); }}
                className="text-xs text-black/45 hover:text-black"
              >
                移除
              </button>
            )}
          </div>
          <p className="mb-3 px-1 text-xs leading-5 text-black/50">选择容器后，素材处理会同时更换餐具；选择“保留原容器”则只优化原图。容器大小自动适配菜品。</p>
          <button
            type="button"
            aria-expanded={containerListOpen}
            aria-controls={containerListOpen ? 'container-preset-list' : undefined}
            onClick={() => setContainerListOpen((open) => !open)}
            className="mb-3 flex w-full items-center gap-3 rounded-xl border border-[#a3c529] bg-[#efffac] p-2 text-left transition hover:bg-[#e9fa96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
          >
            {plate ? (
              <img src={plate.src} alt="" className="h-[72px] w-24 shrink-0 rounded-lg object-cover" />
            ) : (
              <span className="w-24 shrink-0"><ContainerThumbnail id={containerPreset} name={getContainerPreset(containerPreset).name} /></span>
            )}
            <span className="min-w-0 flex-1">
              <span className="block text-xs text-black/55">当前容器</span>
              <span className="mt-0.5 block truncate text-sm font-semibold text-black">{plate ? plate.file.name : getContainerPreset(containerPreset).name}</span>
              <span className="mt-1 block text-xs text-black/55">{containerListOpen ? '收起容器列表' : '点击更换容器'}</span>
            </span>
            <ChevronDown aria-hidden="true" className={`h-4 w-4 shrink-0 text-black/55 transition-transform ${containerListOpen ? 'rotate-180' : ''}`} />
          </button>
          {containerListOpen && (
            <div id="container-preset-list" className="mb-3 grid max-h-80 grid-cols-2 gap-2 overflow-y-auto rounded-xl border border-black/10 bg-white/70 p-2" role="radiogroup" aria-label="选择默认容器">
              {containerPresets.map((item) => {
                const selected = !plate && containerPreset === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    role="radio"
                    aria-checked={selected}
                    onClick={() => { setContainerPreset(item.id); setPlate(null); setFusionResult(''); setContainerListOpen(false); }}
                    className={`min-w-0 rounded-xl border p-2 text-left transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black ${selected ? 'border-[#a3c529] bg-[#efffac] shadow-sm' : 'border-black/10 bg-white hover:border-black/30'}`}
                  >
                    <ContainerThumbnail id={item.id} name={item.name} />
                    <span className="mt-1.5 block truncate text-xs font-medium text-black">{item.name}</span>
                    <span className="block truncate text-[11px] text-black/50">{item.detail}</span>
                  </button>
                );
              })}
            </div>
          )}
          <input
            ref={plateInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={choosePlate}
          />
          <button
            onClick={() => plateInputRef.current?.click()}
            className="flex w-full items-center gap-3 rounded-2xl border border-dashed border-black/20 bg-white/60 p-3 text-left hover:border-black/40"
          >
            {plate ? (
              <img
                src={plate.src}
                alt="标准盘预览"
                className="h-14 w-14 rounded-xl object-cover"
              />
            ) : (
              <span className="grid h-14 w-14 place-items-center rounded-xl bg-black/[.04]">
                <Plus className="h-5 w-5 text-black/45" />
              </span>
            )}
            <span>
              <span className="block max-w-[170px] truncate text-sm font-medium">
                {plate ? plate.file.name : '或上传自己的容器照片'}
              </span>
              <span className="mt-1 block text-xs text-black/40">
                上传后优先使用自定义容器
              </span>
            </span>
          </button>
          <div className="my-5 h-px bg-black/8" />
          <div className="mb-3 flex items-center justify-between px-1"><h2 className="text-sm font-semibold">展示底图</h2>{backdrop && <button onClick={() => setBackdrop(null)} className="text-xs text-black/45 hover:text-black">移除</button>}</div>
          <input ref={backdropInputRef} type="file" accept="image/*" className="hidden" onChange={chooseBackdrop} />
          <button onClick={() => backdropInputRef.current?.click()} className="flex w-full items-center gap-3 rounded-2xl border border-dashed border-black/20 bg-white/60 p-3 text-left hover:border-black/40">
            {backdrop ? <img src={backdrop.src} alt="展示底图预览" className="h-14 w-14 rounded-xl object-cover" /> : <span className="grid h-14 w-14 place-items-center rounded-xl bg-black/[.04]"><Wallpaper className="h-5 w-5 text-black/45" /></span>}
            <span><span className="block max-w-[170px] truncate text-sm font-medium">{backdrop ? backdrop.file.name : '添加展示场景底图'}</span><span className="mt-1 block text-xs text-black/40">处理后可直接合成导出</span></span>
          </button>
        </aside>

        <section className="order-1 min-w-0 md:order-2">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3 px-1">
            <div>
              <p className="text-xs font-medium uppercase tracking-[.16em] text-black/40">
                当前任务
              </p>
              <h2 className="mt-1 text-2xl font-semibold tracking-[-.035em]">
                {projectType === 'fusion' ? '菜品融合' : projectType === 'bundle' ? '套餐组合' : activeMode.title}
              </h2>
            </div>
            <div className="flex gap-2">
              {jobs.length > 0 && (
                <Button
                  variant="outline"
                  onClick={clearJobs}
                  disabled={running || fusionProcessing || bundleProcessing}
                  className="rounded-xl bg-white"
                >
                  <Trash2 className="h-4 w-4" />
                  清空
                </Button>
              )}
              <Button
                onClick={() => inputRef.current?.click()}
                className="rounded-xl bg-[#171815] text-white hover:bg-black"
              >
                <Plus className="h-4 w-4" />
                添加图片
              </Button>
            </div>
          </div>
          {projectType === 'fusion' && (
            <div className="mb-4 rounded-[22px] border border-black/10 bg-[#fafaf7] p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div><h3 className="text-sm font-semibold">融合成一道菜</h3><p className="mt-1 text-xs text-black/45">从下方选 2–8 道原图；只在点击生成时调用一次 API。</p></div>
                <span className="rounded-full bg-black/[.05] px-3 py-1.5 text-xs">已选 {fusionSelection.length} 道</span>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-1 rounded-xl bg-black/[.05] p-1">
                <button onClick={() => { setFusionStyle('new_plate'); setFusionResult(''); }} className={`rounded-lg px-3 py-2 text-xs font-medium ${fusionStyle === 'new_plate' ? 'bg-white shadow-sm' : 'text-black/55'}`}>融合到新容器</button>
                <button onClick={() => { setFusionStyle('into_main'); setFusionResult(''); }} className={`rounded-lg px-3 py-2 text-xs font-medium ${fusionStyle === 'into_main' ? 'bg-white shadow-sm' : 'text-black/55'}`}>加入某道主菜</button>
              </div>
              <p className="mt-2 text-xs leading-5 text-black/55">
                {fusionStyle === 'new_plate'
                  ? `统一盛入${plate ? '上传的容器' : containerPreset === 'original' ? '默认圆形餐盘' : getContainerPreset(containerPreset).name}，原菜容器不会出现在成品中。`
                  : '以选定主菜为底，把其他菜的食材自然加入，保留主菜原有容器。'}
              </p>
              {fusionStyle === 'into_main' && fusionSelection.length > 0 && (
                <label className="mt-3 block text-xs font-medium text-black/65">
                  主菜
                  <select
                    value={fusionSelection.includes(fusionMainId) ? fusionMainId : fusionSelection[0]}
                    onChange={(event) => { setFusionMainId(event.target.value); setFusionResult(''); }}
                    className="mt-1 h-10 w-full rounded-xl border border-black/10 bg-white px-3 text-sm"
                  >
                    {jobs.filter((job) => fusionSelection.includes(job.id)).map((job) => <option key={job.id} value={job.id}>{job.name}</option>)}
                  </select>
                </label>
              )}
              <Button disabled={fusionProcessing || fusionSelection.length < 2 || fusionSelection.length > 8 || !apiConfigured} onClick={() => void buildFusion()} className="mt-4 w-full rounded-xl bg-[#171815] text-white">
                {fusionProcessing ? <><LoaderCircle className="h-4 w-4 animate-spin" />融合中</> : '生成融合菜品'}
              </Button>
              {!apiConfigured && <p className="mt-2 text-xs text-red-600">请先在右上角设置 API。</p>}
              {fusionError && <p role="alert" className="mt-2 text-xs text-red-600">{fusionError}</p>}
              {fusionResult && (
                <div className="mt-4 grid gap-3 rounded-2xl border border-black/10 bg-white p-3 sm:grid-cols-[120px_1fr]">
                  <ImageCopyMenu src={fusionResult} name="融合菜品" onMessage={setAssistantMessage}>
                  <button onClick={() => setPreviewImage({ src: fusionResult, name: `${projectName} · 融合菜品` })} className="w-full cursor-zoom-in rounded-xl">
                    <img src={fusionResult} alt="融合菜品结果" className="aspect-square w-full rounded-xl bg-black/[.03] object-contain" />
                  </button>
                  </ImageCopyMenu>
                  <div className="flex flex-col justify-center"><p className="text-sm font-semibold">融合菜品已生成</p><p className="mt-1 text-xs text-black/45">透明背景 PNG，完整容器</p><Button size="sm" onClick={downloadFusion} className="mt-3 w-fit rounded-lg bg-[#d9ff43] text-black">导出 PNG</Button></div>
                </div>
              )}
            </div>
          )}
          {projectType === 'bundle' && jobs.length > 0 && (
            <div className="mb-4 rounded-[22px] border border-black/10 bg-[#fafaf7] p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div><h3 className="text-sm font-semibold">套餐组合</h3><p className="mt-1 text-xs text-black/45">勾选下方至少 2 张已处理菜品，再生成套餐展示图</p></div>
                <span className="rounded-full bg-black/[.05] px-3 py-1.5 text-xs">已选 {bundleSelection.length} 张</span>
              </div>
              <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto]">
                <div className="grid grid-cols-2 gap-1 rounded-xl bg-black/[.05] p-1">
                  <button onClick={() => setBundleMethod('local')} className={`rounded-lg px-3 py-2 text-xs font-medium ${bundleMethod === 'local' ? 'bg-white shadow-sm' : 'text-black/45'}`}>本地排版 · 免费</button>
                  <button onClick={() => setBundleMethod('ai')} className={`rounded-lg px-3 py-2 text-xs font-medium ${bundleMethod === 'ai' ? 'bg-white shadow-sm' : 'text-black/45'}`}>场景展示</button>
                </div>
                <Button disabled={bundleProcessing || selectedBundleJobs().length < 2 || (bundleMethod === 'ai' && bundlePlacement === 'auto' && !apiConfigured)} onClick={() => void buildBundle()} className="rounded-xl bg-[#171815] text-white">
                  {bundleProcessing ? <><LoaderCircle className="h-4 w-4 animate-spin" />合成中</> : '生成套餐展示图'}
                </Button>
              </div>
              {bundleMethod === 'ai' && (
                <div className="mt-4 space-y-3 rounded-xl border border-black/10 bg-white p-3">
                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={() => setBundlePlacement('manual')} className={`rounded-lg px-3 py-2 text-sm ${bundlePlacement === 'manual' ? 'bg-[#d9ff43] font-semibold' : 'bg-black/[.04]'}`}>手动精确摆放 · 免费</button>
                    <button onClick={() => setBundlePlacement('auto')} className={`rounded-lg px-3 py-2 text-sm ${bundlePlacement === 'auto' ? 'bg-[#d9ff43] font-semibold' : 'bg-black/[.04]'}`}>AI 自动合理摆放 · 调用 API</button>
                  </div>
                  <p className="text-xs text-black/55">{bundlePlacement === 'manual' ? '按下面的预览位置精确合成，使用本地场景背景，不调用 API。' : 'AI 自行安排前后、大小和光影；生成完整的不透明场景，位置不保证精确。'}</p>
                  {!backdrop && <div className="flex flex-wrap items-center gap-2"><span className="text-xs text-black/55">场景背景</span><button onClick={() => setBundleBackground('cream')} className={`rounded-lg border px-3 py-1.5 text-xs ${bundleBackground === 'cream' ? 'border-black bg-[#f1eadf]' : 'border-black/10'}`}>暖色桌面</button><button onClick={() => setBundleBackground('slate')} className={`rounded-lg border px-3 py-1.5 text-xs ${bundleBackground === 'slate' ? 'border-black bg-[#46535b] text-white' : 'border-black/10'}`}>深色桌面</button></div>}
                  {backdrop && <p className="text-xs text-black/55">使用已上传的展示底图：{backdrop.file.name}</p>}
                </div>
              )}
              {bundleMethod === 'ai' && bundlePlacement === 'auto' && !apiConfigured && <p className="mt-2 text-xs text-red-600">AI 自动摆放需要先在右上角设置 API。</p>}
              {selectedBundleJobs().length >= 2 && (bundleMethod === 'local' || bundlePlacement === 'manual') && (
                <div className="mt-4 rounded-xl border border-black/10 bg-white p-3">
                  <div className="mb-3 flex items-center justify-between gap-2"><p className="text-sm font-semibold">摆放预览</p><button onClick={resetBundleLayout} className="rounded-lg border border-black/15 px-3 py-1.5 text-xs hover:bg-black/[.04]">自动合理排版</button></div>
                  <p className="mb-3 text-xs text-black/55">拖动菜品移动，拖动右上角圆点缩放；下方可调整前后层级。导出会按此布局合成。</p>
                  <div ref={bundleStageRef} aria-label="套餐摆放画布" className="relative mx-auto w-full max-w-[480px] overflow-hidden rounded-xl border border-black/10" style={{ aspectRatio: size.replaceAll(' ', '').replace('×', '/'), ...(backdrop ? { backgroundImage: `url(${backdrop.src})`, backgroundSize: 'cover', backgroundPosition: 'center' } : bundleMethod === 'ai' ? { background: bundleBackground === 'slate' ? 'linear-gradient(135deg,#46535b,#202a30)' : 'linear-gradient(135deg,#f5f0e7,#d9d0c2)' } : { backgroundColor: '#fff', backgroundImage: 'linear-gradient(45deg,#ecece8 25%,transparent 25%),linear-gradient(-45deg,#ecece8 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#ecece8 75%),linear-gradient(-45deg,transparent 75%,#ecece8 75%)', backgroundSize: '24px 24px', backgroundPosition: '0 0,0 12px,12px -12px,-12px 0' }) }}>
                    {selectedBundleJobs().map((job, index, selected) => {
                      const layout = bundleLayoutFor(job, index, selected.length);
                      return <div key={job.id} role="group" tabIndex={0} aria-label={`移动 ${job.name}`} onPointerDown={(event) => { activeBundleDrag.current = job.id; event.currentTarget.setPointerCapture(event.pointerId); }} onPointerMove={(event) => { if (activeBundleDrag.current !== job.id || !bundleStageRef.current) return; const rect = bundleStageRef.current.getBoundingClientRect(); updateBundleLayout(job.id, { x: Math.max(0.05, Math.min(0.95, (event.clientX - rect.left) / rect.width)), y: Math.max(0.05, Math.min(0.95, (event.clientY - rect.top) / rect.height)) }); }} onPointerUp={() => { activeBundleDrag.current = null; }} onPointerCancel={() => { activeBundleDrag.current = null; }} onLostPointerCapture={() => { activeBundleDrag.current = null; }} onKeyDown={(event) => { const delta = event.shiftKey ? 0.05 : 0.01; if (event.key === 'ArrowLeft' || event.key === 'ArrowRight' || event.key === 'ArrowUp' || event.key === 'ArrowDown') { event.preventDefault(); updateBundleLayout(job.id, { x: Math.max(0.05, Math.min(0.95, layout.x + (event.key === 'ArrowLeft' ? -delta : event.key === 'ArrowRight' ? delta : 0))), y: Math.max(0.05, Math.min(0.95, layout.y + (event.key === 'ArrowUp' ? -delta : event.key === 'ArrowDown' ? delta : 0))) }); } }} className="group absolute cursor-grab touch-none rounded-lg outline-2 outline-offset-1 outline-transparent focus-visible:outline-black active:cursor-grabbing" style={{ left: `${layout.x * 100}%`, top: `${layout.y * 100}%`, width: `${layout.scale * 100}%`, transform: 'translate(-50%,-50%)', zIndex: layout.order + 1 }}>
                        <img src={job.result} alt={job.name} draggable={false} className="pointer-events-none block h-auto w-full select-none" />
                        <button type="button" aria-label={`调整 ${job.name} 大小`} title="拖动调整大小" onPointerDown={(event) => { event.stopPropagation(); activeBundleDrag.current = null; activeBundleResize.current = { id: job.id, startX: event.clientX, startY: event.clientY, startScale: layout.scale }; event.currentTarget.setPointerCapture(event.pointerId); }} onPointerMove={(event) => { const active = activeBundleResize.current; if (!active || active.id !== job.id || !bundleStageRef.current) return; event.stopPropagation(); const width = bundleStageRef.current.getBoundingClientRect().width; updateBundleLayout(job.id, { scale: Math.max(0.15, Math.min(0.8, active.startScale + 2 * ((event.clientX - active.startX) - (event.clientY - active.startY)) / width)) }); }} onPointerUp={(event) => { event.stopPropagation(); activeBundleResize.current = null; }} onPointerCancel={(event) => { event.stopPropagation(); activeBundleResize.current = null; }} onLostPointerCapture={(event) => { event.stopPropagation(); activeBundleResize.current = null; }} onKeyDown={(event) => { if (['ArrowUp', 'ArrowRight', 'ArrowDown', 'ArrowLeft'].includes(event.key)) { event.preventDefault(); event.stopPropagation(); updateBundleLayout(job.id, { scale: Math.max(0.15, Math.min(0.8, layout.scale + (event.key === 'ArrowUp' || event.key === 'ArrowRight' ? 0.02 : -0.02))) }); } }} className="absolute grid h-8 w-8 touch-none place-items-center rounded-full border-2 border-white bg-[#d9ff43] text-sm font-bold text-black shadow-md hover:scale-110 focus-visible:outline-2 focus-visible:outline-black" style={{ top: '16%', right: '8%', cursor: 'nesw-resize' }}>↗</button>
                      </div>;
                    })}
                  </div>
                  <div className="mt-3 space-y-2">{selectedBundleJobs().map((job, _index, selected) => <div key={job.id} className="flex flex-wrap items-center gap-2 rounded-lg bg-black/[.03] px-3 py-2"><span className="min-w-24 flex-1 truncate text-sm font-medium">{job.name}</span><button onClick={() => updateBundleLayout(job.id, { order: Math.min(...selected.map((item, position) => bundleLayoutFor(item, position, selected.length).order)) - 1 })} className="rounded-md border border-black/15 px-2 py-1 text-xs">移到后面</button><button onClick={() => updateBundleLayout(job.id, { order: Math.max(...selected.map((item, position) => bundleLayoutFor(item, position, selected.length).order)) + 1 })} className="rounded-md border border-black/15 px-2 py-1 text-xs">移到前面</button></div>)}</div>
                </div>
              )}
              {bundleResult && (
                <div className="mt-4 grid gap-3 rounded-2xl border border-black/10 bg-white p-3 sm:grid-cols-[120px_1fr]">
                  <ImageCopyMenu src={bundleResult} name="套餐展示图" onMessage={setAssistantMessage}>
                  <button onClick={() => setPreviewImage({ src: bundleResult, name: `${projectName} · 套餐展示图` })} className="group/preview relative w-full cursor-zoom-in rounded-xl">
                    <img src={bundleResult} alt="套餐组合结果" className="aspect-square w-full rounded-xl bg-black/[.03] object-contain" />
                    <span className="absolute bottom-2 right-2 grid h-7 w-7 place-items-center rounded-full bg-black/65 text-white opacity-0 transition group-hover/preview:opacity-100"><ZoomIn className="h-3.5 w-3.5" /></span>
                  </button>
                  </ImageCopyMenu>
                  <div className="flex flex-col justify-center"><p className="text-sm font-semibold">{projectName} · 套餐展示图</p><p className="mt-1 text-xs text-black/45">已按当前输出尺寸和摆放设置生成</p><div className="mt-3 flex flex-wrap gap-2">{bundleMethod === 'local' && !backdrop && <Button variant="outline" size="sm" onClick={() => void repairBundleTransparency()} className="rounded-lg">清理透明边缘</Button>}<Button variant="outline" size="sm" onClick={() => void copyBundle()} className="rounded-lg">复制</Button><Button size="sm" onClick={downloadBundle} className="rounded-lg bg-[#d9ff43] text-black">导出 PNG</Button></div></div>
                </div>
              )}
            </div>
          )}
          <input
            ref={inputRef}
            type="file"
            accept="image/*,.zip,application/zip"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files) void addFilesAndArchives(e.target.files);
              e.target.value = '';
            }}
          />
          {jobs.length === 0 ? (
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragging(true);
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              className={`grid min-h-[610px] place-items-center rounded-[28px] border-2 border-dashed bg-[#fafaf7] p-8 text-center transition ${dragging ? 'border-[#9fca00] bg-[#f5ffd2]' : 'border-black/15 hover:border-black/35'}`}
            >
              <div>
                <div className="relative mx-auto mb-7 h-28 w-36">
                  <div className="absolute left-0 top-5 h-24 w-24 -rotate-6 rounded-[22px] border border-black/10 bg-white shadow-xl" />
                  <div className="absolute right-0 top-0 grid h-24 w-24 rotate-6 place-items-center rounded-[22px] bg-[#d9ff43] shadow-xl">
                    <ImagePlus className="h-9 w-9" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold tracking-tight">
                  拖入、选择或粘贴菜品图片
                </h3>
                <p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-black/45">
                  支持 JPG、PNG、WEBP、截图和 ZIP 压缩包；复制图片后可直接按
                  Ctrl+V
                </p>
                <div className="mt-5 flex flex-wrap justify-center gap-2">
                  <button
                    onClick={() => inputRef.current?.click()}
                    className="inline-flex items-center gap-2 rounded-full border border-black/10 bg-white px-4 py-2 text-sm font-medium hover:bg-black/[.03]"
                  >
                    <Upload className="h-4 w-4" />
                    选择图片
                  </button>
                  <button
                    onClick={pasteFromClipboard}
                    className="inline-flex items-center gap-2 rounded-full bg-[#171815] px-4 py-2 text-sm font-medium text-white hover:bg-black"
                  >
                    <ClipboardPaste className="h-4 w-4" />
                    粘贴图片
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {jobs.map((job) => (
                <article
                  key={job.id}
                  className="group overflow-hidden rounded-[22px] border border-black/10 bg-[#fafaf7] shadow-[0_10px_30px_rgba(0,0,0,.035)]"
                >
                  <ImageCopyMenu src={job.result || job.src} name={job.name || job.file.name} onMessage={setAssistantMessage} className="checkerboard relative aspect-square overflow-hidden">
                    <button
                      onClick={() => setPreviewImage({ src: job.result || job.src, name: job.name || job.file.name })}
                      aria-label={`放大查看 ${job.name || job.file.name}`}
                      className="h-full w-full cursor-zoom-in"
                    >
                      <img src={job.result || job.src} alt={job.file.name} className="h-full w-full object-contain" />
                    </button>
                    <span className="pointer-events-none absolute bottom-3 right-3 grid h-8 w-8 place-items-center rounded-full bg-black/65 text-white opacity-0 shadow transition group-hover:opacity-100"><ZoomIn className="h-4 w-4" /></span>
                    <div className="absolute left-3 top-3 rounded-full bg-black/70 px-2.5 py-1 text-[11px] text-white backdrop-blur">
                      {job.status === 'done'
                        ? '已完成'
                        : job.status === 'processing'
                          ? '处理中'
                          : job.status === 'error'
                            ? '需要重试'
                            : '待处理'}
                    </div>
                    {projectType === 'bundle' && (
                      <button
                        disabled={!job.result}
                        onClick={() => setBundleSelection((current) => current.includes(job.id) ? current.filter((id) => id !== job.id) : [...current, job.id])}
                        className={`absolute bottom-3 left-3 flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium shadow backdrop-blur ${bundleSelection.includes(job.id) ? 'bg-[#d9ff43] text-black' : 'bg-white/90 text-black'} disabled:cursor-not-allowed disabled:opacity-45`}
                      >
                        {bundleSelection.includes(job.id) && <Check className="h-3.5 w-3.5" />}
                        {job.result ? (bundleSelection.includes(job.id) ? '已选入套餐' : '选择组合') : '处理后可选'}
                      </button>
                    )}
                    {projectType === 'fusion' && (
                      <button
                        onClick={() => { setFusionSelection((current) => current.includes(job.id) ? current.filter((id) => id !== job.id) : current.length < 8 ? [...current, job.id] : current); setFusionResult(''); }}
                        className={`absolute bottom-3 left-3 flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium shadow backdrop-blur ${fusionSelection.includes(job.id) ? 'bg-[#d9ff43] text-black' : 'bg-white/90 text-black'}`}
                        aria-pressed={fusionSelection.includes(job.id)}
                      >
                        {fusionSelection.includes(job.id) && <Check className="h-3.5 w-3.5" />}
                        {fusionSelection.includes(job.id) ? '已选入融合' : '选择融合'}
                      </button>
                    )}
                    <button
                      aria-label="移除图片"
                      disabled={job.status === 'processing' || batchProcessing}
                      onClick={() => {
                        setJobs((items) =>
                          items.filter((item) => item.id !== job.id),
                        );
                        setFusionSelection((current) => current.filter((id) => id !== job.id));
                        setBundleSelection((current) => current.filter((id) => id !== job.id));
                        setBundleResult('');
                        if (fusionMainId === job.id) setFusionMainId('');
                        setFusionResult('');
                      }}
                      className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-white/85 opacity-0 shadow transition group-hover:opacity-100"
                    >
                      <X className="h-4 w-4" />
                    </button>
                    {job.status === 'processing' && (
                      <div className="pointer-events-none absolute inset-0 grid place-items-center bg-white/35 backdrop-blur-[2px]">
                        <LoaderCircle className="h-8 w-8 animate-spin" />
                      </div>
                    )}
                  </ImageCopyMenu>
                  <div className="p-3.5">
                    <div className="flex items-center gap-2">
                      <input
                        aria-label="图片名称"
                        value={job.name}
                        onChange={(event) => updateJob(job.id, { name: event.target.value })}
                        className="min-w-0 flex-1 rounded-lg bg-transparent px-1 text-sm font-medium outline-none focus:bg-black/[.04]"
                      />
                      {job.result && (
                        <>
                          <button
                            onClick={() => void repairTransparency(job)}
                            aria-label="清理透明边缘"
                            title="清理透明背景上的小黑点和盘沿杂色"
                            className="text-[#789500]"
                          >
                            <Sparkles className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => copyResult(job)}
                            aria-label="复制成品"
                            title="复制成品"
                          >
                            <Copy className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => void download(job)}
                            aria-label="下载"
                            title="下载 PNG"
                          >
                            <Download className="h-4 w-4" />
                          </button>
                        </>
                      )}
                      <MoreHorizontal className="h-4 w-4 text-black/35" />
                    </div>
                    {job.result && backdrop && (
                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <button onClick={() => void copyDisplay(job)} className="rounded-lg border border-black/10 bg-white px-2 py-2 text-xs font-medium hover:bg-black/[.03]">复制展示图</button>
                        <button onClick={() => void exportDisplay(job)} className="rounded-lg bg-[#d9ff43] px-2 py-2 text-xs font-semibold hover:bg-[#c9ef38]">导出展示图</button>
                      </div>
                    )}
                    {engine === 'api' && (
                      <Button size="sm" disabled={job.status === 'processing' || batchProcessing || fusionProcessing || bundleProcessing} onClick={() => void processSingle(job)} className="mt-3 w-full rounded-xl bg-[#d9ff43] text-black hover:bg-[#c9ef38]">
                        {job.status === 'processing' ? <><LoaderCircle className="h-4 w-4 animate-spin" />处理中 · 最长十分钟</> : <><Sparkles className="h-4 w-4" />{job.result ? '重新处理这张' : job.status === 'error' ? '重试这张' : '处理这张'}</>}
                      </Button>
                    )}
                    {job.status === 'processing' && (
                      <Progress value={job.progress} className="mt-3 h-1.5" />
                    )}
                    {job.error && (
                      <p className="mt-2 text-xs text-red-600">{job.error}</p>
                    )}
                  </div>
                </article>
              ))}
              <button
                onClick={() => inputRef.current?.click()}
                className="grid min-h-52 place-items-center rounded-[22px] border border-dashed border-black/20 bg-white/30 text-sm text-black/45 hover:bg-white/60"
              >
                <span className="grid place-items-center gap-2">
                  <Plus className="h-6 w-6" />
                  继续添加
                </span>
              </button>
            </div>
          )}
        </section>

        <aside className="order-3 rounded-[24px] border border-black/10 bg-[#fafaf7] p-5 md:col-span-2 lg:col-span-1 lg:min-h-[calc(100vh-112px)]">
          <div className="mb-5">
            <h2 className="mb-2 text-sm font-semibold">处理引擎</h2>
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-black/[.05] p-1">
              <button
                onClick={() => setEngine('api')}
                className={`rounded-lg px-2 py-2 text-xs font-medium transition ${engine === 'api' ? 'bg-white shadow-sm' : 'text-black/45'}`}
              >
                API 自动处理
              </button>
              <button
                onClick={() => setEngine('assistant')}
                className={`rounded-lg px-2 py-2 text-xs font-medium transition ${engine === 'assistant' ? 'bg-white shadow-sm' : 'text-black/45'}`}
              >
                通用 AI 辅助
              </button>
            </div>
          </div>
          <h2 className="text-sm font-semibold">处理参数</h2>
          <div className="mt-5 space-y-5">
            <label className="block">
              <span className="mb-2 block text-xs font-medium text-black/55">
                目标角度
              </span>
              <span className="relative block">
                <select
                  value={angle}
                  onChange={(e) => setAngle(e.target.value)}
                  className="h-11 w-full appearance-none rounded-xl border border-black/10 bg-white px-3 pr-9 text-sm outline-none focus:border-black/35"
                >
                  {angles.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-3.5 h-4 w-4 text-black/40" />
              </span>
            </label>
            <label className="block">
              <span className="mb-2 block text-xs font-medium text-black/55">
                输出尺寸
              </span>
              <span className="relative block">
                <select
                  value={size}
                  onChange={(e) => setSize(e.target.value)}
                  className="h-11 w-full appearance-none rounded-xl border border-black/10 bg-white px-3 pr-9 text-sm outline-none focus:border-black/35"
                >
                  {sizes.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-3.5 h-4 w-4 text-black/40" />
              </span>
            </label>
            <div>
              <div className="mb-3 flex items-center justify-between text-xs font-medium text-black/55">
                <span>优化强度</span>
                <span className="font-mono text-black">{strength}%</span>
              </div>
              <input
                aria-label="优化强度"
                aria-describedby="strength-description"
                type="range"
                min="20"
                max="100"
                value={strength}
                onChange={(e) => setStrength(Number(e.target.value))}
                className="w-full accent-black"
              />
              <div id="strength-description" aria-live="polite" className="mt-3 rounded-xl bg-black/[0.035] p-3 text-xs leading-relaxed text-black/65">
                <p><span className="font-medium text-black">{getOptimizationStrengthProfile(strength).label}：</span>{getOptimizationStrengthProfile(strength).description}</p>
              </div>
            </div>
            <label className="block">
              <span className="mb-2 flex items-center justify-between text-xs font-medium text-black/55">
                <span>特殊定制说明</span>
                <span>{customInstruction.length}/1000</span>
              </span>
              <textarea
                value={customInstruction}
                maxLength={1000}
                rows={4}
                onChange={(event) => setCustomInstruction(event.target.value)}
                placeholder="例如：画面中只保留一盘菜，去掉被提起的面条；不要改变盘内菜品。"
                className="w-full resize-y rounded-xl border border-black/10 bg-white px-3 py-2.5 text-sm leading-5 outline-none placeholder:text-black/30 focus:border-black/35"
              />
              <div className="mt-2 flex flex-wrap gap-1.5">
                {customPresets.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setCustomInstruction((current) => current ? `${current}；${preset}`.slice(0, 1000) : preset)}
                    className="rounded-full border border-black/10 bg-white px-2.5 py-1.5 text-[11px] text-black/55 hover:border-black/25 hover:text-black"
                  >
                    + {preset}
                  </button>
                ))}
                {customInstruction && <button type="button" onClick={() => setCustomInstruction('')} className="rounded-full px-2.5 py-1.5 text-[11px] text-red-500 hover:bg-red-50">清空说明</button>}
              </div>
              <p className="mt-1.5 text-xs leading-5 text-black/40">用于补充默认参数无法表达的删除、保留、位置和细节要求。</p>
            </label>
            <div className="flex items-center justify-between rounded-xl border border-black/8 bg-white p-3">
              <div>
                <p className="text-sm font-medium">保护菜品形态</p>
                <p className="mt-0.5 text-xs text-black/40">
                  尽量保持分量与摆盘
                </p>
              </div>
              <Switch checked={protectFood} onCheckedChange={setProtectFood} />
            </div>
            <div className="rounded-xl bg-[#ecede7] p-3 text-xs leading-5 text-black/50">
              <strong className="text-black/70">输出标准</strong>
              <br />
              {projectType === 'bundle'
                ? bundleMethod === 'ai' || backdrop
                  ? '不透明场景 PNG · 按手动布局或 AI 自动构图 · 无文字水印'
                  : '透明背景 PNG · 按预览中的位置、大小和层级合成'
                : '透明背景 PNG · 无文字 · 无水印 · 主体居中 · 保留安全边距'}
            </div>
          </div>
          <div className="mt-6 border-t border-black/8 pt-5">
            {doneCount > 0 && (
              <Button
                variant="outline"
                onClick={exportCompletedZip}
                className="mb-2 h-11 w-full rounded-xl bg-white"
              >
                <FileArchive className="h-4 w-4" />
                打包下载 {doneCount} 张成品
              </Button>
            )}
            {engine === 'assistant' && (
              <div className="mb-4 rounded-xl border border-[#c8e94f] bg-[#f4ffd0] p-3">
                <p className="text-sm font-semibold">通用 AI 辅助流程</p>
                <p className="mt-1 text-xs leading-5 text-black/50">
                  适用于支持图片输入和图片编辑的 AI 平台：先复制图片，再复制通用处理指令。
                </p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    disabled={!jobs.length}
                    onClick={copyFirstImageForAssistant}
                    className="rounded-lg bg-white text-xs"
                  >
                    1. 复制首图
                  </Button>
                  <Button
                    onClick={copyAssistantPrompt}
                    className="rounded-lg bg-[#171815] text-xs text-white"
                  >
                    2. 复制指令
                  </Button>
                </div>
              </div>
            )}
            {jobs.length > 0 && (
              <div className="mb-4">
                <div className="mb-2 flex justify-between text-xs text-black/45">
                  <span>
                    {running
                      ? batchProcessing ? '正在批量处理' : '正在单张处理'
                      : `${doneCount}/${jobs.length} 张已完成`}
                  </span>
                  <span>{averageProgress}%</span>
                </div>
                <Progress value={averageProgress} className="h-1.5" />
              </div>
            )}
            <Button
              disabled={!jobs.length || busy || (engine === 'api' && pendingCount === 0)}
              onClick={engine === 'api' ? processAll : copyAssistantPrompt}
              className="h-12 w-full rounded-xl bg-[#d9ff43] font-semibold text-black shadow-[0_8px_22px_rgba(140,180,0,.18)] hover:bg-[#c9ef38] disabled:bg-black/10"
            >
              {running ? (
                <>
                  <LoaderCircle className="h-4 w-4 animate-spin" />
                  处理中
                </>
              ) : !jobs.length ? (
                '请先添加菜品图片'
              ) : engine === 'assistant' ? (
                <>
                  <ClipboardPaste className="h-4 w-4" />
                  复制通用 AI 指令
                </>
              ) : pendingCount === 0 ? (
                <><Check className="h-4 w-4" />全部处理完成</>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  批量处理 {pendingCount ? `${pendingCount} 张` : ''}
                </>
              )}
            </Button>
            {engine === 'api' && <p className="mt-2 text-xs leading-5 text-black/50">每张图最多等待十分钟，也可在图片下方单独处理；失败后由你决定是否重试。</p>}
            {running && (
              <Button variant="outline" onClick={stopProcessing} className="mt-2 h-11 w-full rounded-xl border-red-200 bg-white text-red-600 hover:bg-red-50">
                <X className="h-4 w-4" />
                终止当前处理
              </Button>
            )}
            <p className="mt-3 text-center text-[11px] text-black/35">
              {engine === 'api'
                ? '处理过程中请保持此页面开启'
                : '辅助模式不调用本网页 API，费用与能力取决于你使用的 AI 平台'}
            </p>
          </div>
        </aside>
      </div>
      {assistantMessage && (
        <div role="status" aria-live="polite" className="fixed bottom-5 left-1/2 z-[80] flex max-w-[calc(100vw-2rem)] -translate-x-1/2 items-center gap-3 rounded-2xl bg-[#171815] px-4 py-3 text-sm text-white shadow-2xl">
          <Check className="h-4 w-4 shrink-0 text-[#d9ff43]" />
          <span>{assistantMessage}</span>
          <button onClick={() => setAssistantMessage('')} aria-label="关闭提示" className="ml-1 text-white/55 hover:text-white"><X className="h-4 w-4" /></button>
        </div>
      )}
      {previewImage && (
        <div
          role="presentation"
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/85 p-4 backdrop-blur-md sm:p-8"
          onClick={() => setPreviewImage(null)}
        >
          <div role="dialog" aria-modal="true" aria-label={`图片预览：${previewImage.name}`} className="relative flex max-h-full max-w-[min(94vw,1400px)] flex-col items-center" onClick={(event) => event.stopPropagation()}>
            <ImageCopyMenu src={previewImage.src} name={previewImage.name} onMessage={setAssistantMessage} className="checkerboard max-h-[82vh] overflow-hidden rounded-2xl shadow-2xl">
              <img src={previewImage.src} alt={previewImage.name} className="max-h-[82vh] max-w-[92vw] object-contain" />
            </ImageCopyMenu>
            <p className="mt-3 max-w-[80vw] truncate text-sm font-medium text-white/85">{previewImage.name}</p>
            <Button variant="outline" className="mt-3 rounded-full bg-white" onClick={() => void copyImageToClipboard(previewImage.src).then(() => setAssistantMessage('图片已复制，可直接粘贴。')).catch(() => setAssistantMessage('复制失败，请通过右键菜单重试或下载图片。'))}><Copy className="h-4 w-4" />复制图片</Button>
            <button onClick={() => setPreviewImage(null)} aria-label="关闭图片预览" className="absolute -right-2 -top-2 grid h-10 w-10 place-items-center rounded-full bg-white text-black shadow-xl sm:-right-5 sm:-top-5"><X className="h-5 w-5" /></button>
          </div>
        </div>
      )}
      {settingsOpen && (
        <div
          role="presentation"
          className="fixed inset-0 z-50 grid place-items-center bg-black/35 p-4 backdrop-blur-sm"
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="api-settings-title"
            ref={settingsPanelRef}
            tabIndex={-1}
            className="max-h-[calc(100dvh-2rem)] w-full max-w-lg overflow-y-auto rounded-[24px] bg-white p-6 shadow-2xl outline-none"
            onKeyDown={(event) => {
              if (event.key !== 'Tab') return;
              const fields = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), select:not(:disabled)'));
              const first = fields[0];
              const last = fields[fields.length - 1];
              if (event.shiftKey && (document.activeElement === first || document.activeElement === event.currentTarget)) { event.preventDefault(); last?.focus(); }
              else if (!event.shiftKey && (document.activeElement === last || document.activeElement === event.currentTarget)) { event.preventDefault(); first?.focus(); }
            }}
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div>
                <h2 id="api-settings-title" className="text-lg font-semibold">API 设置</h2>
                <p className="mt-1 text-xs text-black/45">
                  填写连接信息 → 测试连接 → 选择模型并保存
                </p>
              </div>
              <Button
                aria-label="关闭 API 设置"
                variant="ghost"
                size="icon"
                className="rounded-full"
                disabled={savingKey || testingApi}
                onClick={requestSettingsClose}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="mt-5 rounded-2xl border border-black/10 bg-[#f7f7f3] p-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">API 连接</p>
                <span
                  className={`rounded-full px-2 py-1 text-[11px] ${apiConfigured ? 'bg-lime-200 text-lime-900' : 'bg-black/5 text-black/45'}`}
                >
                  {apiConfigured ? '已配置' : '未配置'}
                </span>
              </div>
              <label className="mt-4 block">
                <span className="mb-2 block text-xs font-medium text-black/55">
                  API 地址
                </span>
                <input
                  type="url"
                  disabled={savingKey || testingApi}
                  value={apiBaseUrl}
                  onChange={(event) => setApiBaseUrl(event.target.value)}
                  placeholder="https://api.example.com/v1"
                  className="h-11 w-full rounded-xl border border-black/10 bg-white px-3 text-sm outline-none focus:border-black/40"
                />
              </label>
              <label className="mt-4 block text-xs font-medium text-black/55" htmlFor="api-key">API 密钥</label>
              <div className="relative mt-2">
              <input
                id="api-key"
                type={showApiKey ? 'text' : 'password'}
                disabled={savingKey || testingApi}
                autoComplete="off"
                value={apiKeyInput}
                onChange={(event) => setApiKeyInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' && !savingKey && !testingApi) void saveApiKey();
                }}
                placeholder={
                  apiConfigured ? '输入新密钥可替换当前密钥' : '输入 API 密钥'
                }
                className="h-11 w-full rounded-xl border border-black/10 bg-white px-3 pr-16 text-sm outline-none focus:border-black/40"
              />
              <button type="button" className="absolute right-3 top-3 text-xs" onClick={() => setShowApiKey(!showApiKey)}>{showApiKey ? '隐藏' : '显示'}</button>
              </div>
              <p className="mt-2 text-xs leading-5 text-black/45">
                每个人使用自己的 API 密钥，费用由 API 服务商收取，无需登录或充值点数。设置仅保存在本机；已保存密钥时可留空，连接测试不会保存修改。
              </p>
              <Button
                type="button"
                variant="outline"
                disabled={testingApi || savingKey}
                onClick={testApiConnection}
                className="mt-3 w-full rounded-xl bg-white"
              >
                {testingApi ? (
                  <>
                    <LoaderCircle className="h-4 w-4 animate-spin" />
                    连接测试中
                  </>
                ) : (
                  '连接测试并获取模型'
                )}
              </Button>
              <label className="mt-5 block border-t border-black/8 pt-4">
                <span className="mb-2 block text-sm font-medium">图像模型</span>
                <span className="relative block">
                  <input
                    list="image-model-options"
                    placeholder="输入 API 服务商提供的图像模型 ID"
                    value={imageModel}
                    disabled={savingKey || testingApi}
                    onChange={(event) => setImageModel(event.target.value)}
                    className="h-12 w-full appearance-none rounded-xl border border-black/10 bg-white px-3 pr-9 text-sm outline-none focus:border-black/40"
                  />
                  <datalist id="image-model-options">
                    {availableModels.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.name} · {item.detail}
                      </option>
                    ))}
                  </datalist>
                </span>
                <span className="mt-2 block text-xs font-normal leading-5 text-black/45">可从建议中选择，也可直接输入模型 ID。模型必须支持图像编辑；以你的 API 服务商说明为准。</span>
              </label>
              {apiSettingMessage && (
                <p
                  role={apiMessageStatus === 'error' ? 'alert' : 'status'}
                  className={`mt-3 rounded-xl p-3 text-xs leading-5 ${apiMessageStatus === 'error' ? 'bg-red-50 text-red-700' : apiMessageStatus === 'success' ? 'bg-lime-50 text-lime-800' : 'bg-black/5 text-black/60'}`}
                >
                  {apiSettingMessage}
                </p>
              )}
            </div>
            {confirmSettingsClose && (
              <div role="alert" className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm">
                <p>有未保存的修改。关闭后填写内容仍会保留，可稍后继续。</p>
                <div className="mt-3 flex gap-2">
                  <Button variant="outline" onClick={() => setConfirmSettingsClose(false)}>继续设置</Button>
                  <Button variant="outline" onClick={() => { setConfirmSettingsClose(false); setSettingsOpen(false); setShowApiKey(false); }}>稍后再设置</Button>
                </div>
              </div>
            )}
            <div className="mt-5 flex gap-2">
              {apiConfigured && (
                <Button
                  variant="outline"
                  className="rounded-xl"
                  onClick={clearApiKey}
                  disabled={savingKey || testingApi}
                >
                  清除密钥
                </Button>
              )}
              <Button
                disabled={(!apiConfigured && !apiKeyInput.trim()) || savingKey || testingApi}
                className="flex-1 rounded-xl"
                onClick={saveApiKey}
              >
                {savingKey ? (
                  <>
                    <LoaderCircle className="h-4 w-4 animate-spin" />
                    保存中
                  </>
                ) : (
                  '保存设置'
                )}
              </Button>
            </div>
          </div>
        </div>
      )}

    </main>
  );
}
