import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';

const directory = path.resolve(process.argv[2]);
const application = path.join(directory, 'resources', 'app');
for (const relative of ['盘上造物.exe', 'resources/runtime/node.exe', 'resources/app/electron/main.cjs', 'resources/app/dist/server/wrangler.json', '使用说明.txt']) {
  assert.ok(fs.existsSync(path.join(directory, relative)), `缺少运行文件：${relative}`);
}
const secrets = [];
if (fs.existsSync('.api-config.local.json')) {
  const key = JSON.parse(fs.readFileSync('.api-config.local.json', 'utf8')).apiKey;
  if (key) secrets.push(key);
}
if (fs.existsSync('.env.local')) {
  const match = fs.readFileSync('.env.local', 'utf8').match(/^OPENAI_API_KEY\s*=\s*(.+)$/m);
  const key = match?.[1].trim().replace(/^['"]|['"]$/g, '');
  if (key) secrets.push(key);
}
for (const name of ['.env.local', '.api-config.local.json', '.wrangler', 'outputs']) {
  assert.ok(!fs.existsSync(path.join(application, name)), `混入私人配置或开发数据：${name}`);
}
assert.ok(!fs.existsSync(path.join(directory, 'data')), '发布目录混入使用者数据');
const runtimeManifest = JSON.parse(fs.readFileSync(path.join(application, 'package.json'), 'utf8'));
assert.deepEqual(Object.keys(runtimeManifest.dependencies || {}), ['wrangler'], '运行依赖清单不是精简版本');
let scanned = 0;
function scan(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const filename = path.join(directory, entry.name);
    if (entry.isSymbolicLink()) throw new Error(`发布文件含本机链接：${filename}`);
    if (entry.isDirectory()) scan(filename);
    else {
      scanned += 1;
      const bytes = fs.readFileSync(filename);
      assert.ok(!secrets.some((key) => bytes.includes(Buffer.from(key))), '应用文件混入本机 API 密钥');
    }
  }
}
for (const area of ['dist', 'electron']) scan(path.join(application, area));
console.log(`运行文件和隐私检查通过：${scanned} 个应用文件，未包含本机 API 密钥或私人配置。`);
