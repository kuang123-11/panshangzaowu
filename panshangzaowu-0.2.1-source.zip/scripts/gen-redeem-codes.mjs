// 盘上造物 · 兑换码生成脚本（运营用，本地运行）
// 用法：node scripts/gen-redeem-codes.mjs <点数> <数量>
// 示例：node scripts/gen-redeem-codes.mjs 20 10   -> 生成 10 个可兑换 20 点的兑换码
// 输出 Postgres INSERT 语句，可粘贴到 WorkBuddy 云数据库管理台执行入库

import { randomBytes } from 'node:crypto';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function genCode() {
  const bytes = randomBytes(12);
  const chars = Array.from(bytes).map((b) => ALPHABET[b % ALPHABET.length]).join('');
  return `PZ-${chars.match(/.{1,4}/g).join('-')}`;
}

const points = Number(process.argv[2]);
const count = Number(process.argv[3]);

if (!Number.isInteger(points) || points <= 0 || !Number.isInteger(count) || count <= 0) {
  console.error('用法：node scripts/gen-redeem-codes.mjs <点数> <数量>');
  console.error('示例：node scripts/gen-redeem-codes.mjs 20 10');
  process.exit(1);
}

const codes = [];
for (let i = 0; i < count; i++) codes.push({ code: genCode(), points });

// 输出兑换码清单（可复制给用户/客服）
console.log('===== 兑换码清单（点数 %d，共 %d 个）=====', points, count);
console.log(codes.map((c) => `${c.code}  ->  ${c.points} 点`).join('\n'));

// 输出 Postgres SQL（入库用）
const values = codes.map((c) => `('${c.code}', ${c.points})`).join(',\n');
console.log('\n===== SQL（在云数据库管理台执行入库）=====');
console.log(`INSERT INTO redeem_codes (code, points) VALUES\n${values};`);
