import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import ts from 'typescript';

const code = ts.transpileModule(readFileSync(new URL('../lib/green-screen.ts', import.meta.url), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const module = { exports: {} };
new Function('module', 'exports', code)(module, module.exports);
const { removeGreenScreen } = module.exports;
const width = 48, height = 48;
const pixels = new Uint8ClampedArray(width * height * 4);
function fill(x1, y1, x2, y2, rgba) {
  for (let y = y1; y < y2; y += 1) for (let x = x1; x < x2; x += 1) pixels.set(rgba, (y * width + x) * 4);
}
const pixel = (x, y) => Array.from(pixels.slice((y * width + x) * 4, (y * width + x) * 4 + 4));
fill(0, 0, width, height, [0, 255, 0, 255]);
fill(7, 7, 41, 41, [255, 255, 255, 255]); // solid plate
fill(7, 8, 8, 40, [128, 255, 128, 255]); // green/white antialiasing
fill(12, 12, 16, 16, [45, 125, 35, 255]); // natural dark leaves
fill(12, 20, 16, 24, [40, 180, 40, 255]); // brighter green food
fill(22, 16, 28, 22, [0, 255, 0, 255]); // enclosed handle opening
fill(23, 17, 27, 21, [8, 210, 8, 255]); // variation inside the hole
fill(32, 28, 36, 32, [4, 205, 7, 255]); // entirely shaded enclosed gap
assert.equal(removeGreenScreen(pixels, width, height, true), true);
assert.equal(pixel(0, 0)[3], 0);
assert.equal(pixel(24, 19)[3], 0, 'enclosed shaded green is removed');
assert.equal(pixel(33, 29)[3], 0, 'second enclosed gap is removed');
assert.deepEqual(pixel(13, 13), [45, 125, 35, 255]);
assert.deepEqual(pixel(13, 21), [40, 180, 40, 255]);
assert.deepEqual(pixel(20, 30), [255, 255, 255, 255]);
const edge = pixel(7, 30);
assert.ok(edge[3] >= 120 && edge[3] <= 135);
assert.ok(edge[0] >= 250 && edge[1] >= 250 && edge[2] >= 250, 'white edge loses green spill');

fill(0, 0, width, height, [0, 200, 255, 255]);
assert.throws(() => removeGreenScreen(pixels, width, height, true), /纯绿幕/);
fill(0, 0, width, height, [255, 255, 255, 255]);
assert.equal(removeGreenScreen(pixels, width, height), false);
assert.equal(pixel(0, 0)[3], 255, 'white backgrounds are not mistaken for the matte');
fill(0, 0, width, height, [0, 0, 0, 0]);
fill(10, 10, 30, 30, [255, 255, 255, 255]);
assert.equal(removeGreenScreen(pixels, width, height, true), false, 'already-transparent PNG is accepted');
assert.equal(pixel(15, 15)[3], 255);
console.log('绿幕外围、封闭孔隙、绿色食材保护、白色边缘去绿、错误背景保护及透明 PNG 验证通过。');
