const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const testAppRoot = process.argv[2] ? path.resolve(process.argv[2]) : root;
const packaged = Boolean(process.argv[2]);
const testProcess = Object.create(process);
if (packaged) Object.defineProperty(testProcess, 'resourcesPath', { value: path.dirname(testAppRoot) });
const userData = fs.mkdtempSync(path.join(os.tmpdir(), 'panshang-settings-test-'));
testProcess.env = { ...process.env, PANSHANG_DATA_DIR: userData };
let ready;
let child;
let loaded;
const loadedPromise = new Promise((resolve) => { loaded = resolve; });
class Window {
  constructor() { this.webContents = { setWindowOpenHandler() {}, on() {} }; }
  show() {}
  async loadURL(url) { if (url.startsWith('http:')) loaded(); }
}
const electron = {
  app: { isPackaged: packaged, getAppPath: () => testAppRoot, getPath: () => userData,
    setPath() {}, requestSingleInstanceLock: () => true,
    whenReady: () => ({ then: (callback) => { ready = callback; } }), on() {},
    quit: () => loaded(new Error('启动失败')) },
  BrowserWindow: Window,
  dialog: { showErrorBox: (_, message) => loaded(new Error(message)) }, shell: {},
};
const context = vm.createContext({
  require: (name) => name === 'electron' ? electron : name === 'node:child_process'
    ? { spawn: (...args) => { child = require(name).spawn(...args); return child; } } : require(name),
  process: testProcess, console, setTimeout, clearTimeout, Buffer,
});
vm.runInContext(fs.readFileSync(path.join(testAppRoot, 'electron/main.cjs'), 'utf8').replace('const PORT = 3210;', 'const PORT = 3229;'), context);
(async () => {
  try {
    await ready();
    const startupError = await loadedPromise;
    if (startupError) throw startupError;
    const pageResponse = await fetch('http://127.0.0.1:3229/');
    assert.equal(pageResponse.status, 200);
    const markup = await pageResponse.text();
    assert.ok(markup.includes('十分钟'), '首页缺少新版十分钟提示');
    assert.ok(markup.includes('素材处理'), '首页缺少统一素材处理入口');
    assert.ok(markup.includes('寸灰'), '首页缺少个人署名');
    assert.ok(!markup.includes('登录 / 注册'), '本地版不应显示登录入口');
    assert.ok(markup.includes('请先添加菜品图片'), '空项目不应误显示处理完成');
    const url = 'http://127.0.0.1:3229/api/settings';
    const initial = await fetch(url).then((response) => response.json());
    assert.equal(initial.configured, false);
    const crossSite = await fetch(url, { method: 'DELETE', headers: { Origin: 'https://example.invalid' } });
    assert.equal(crossSite.status, 403, '跨站请求不应清除本机配置');
    const invalid = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'http://127.0.0.1:3229' }, body: JSON.stringify({ apiKey: 'short' }) });
    assert.equal(invalid.status, 400, '无效密钥应给出明确提示');
    const config = { apiKey: 'test-local-key-not-a-secret', baseUrl: 'https://example.com/v1', model: 'test-image-model' };
    const saved = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'http://127.0.0.1:3229' }, body: JSON.stringify(config) });
    assert.equal(saved.status, 200, JSON.stringify(await saved.json()));
    assert.deepEqual(JSON.parse(fs.readFileSync(path.join(userData, '.api-config.local.json'), 'utf8')), config);
    const read = await fetch(url).then((response) => response.json());
    assert.equal(read.configured, true);
    assert.equal(read.model, config.model);
    assert.equal(read.apiKey, undefined);
    const removed = await fetch(url, { method: 'DELETE', headers: { Origin: 'http://127.0.0.1:3229' } });
    assert.equal(removed.status, 200);
    assert.equal(JSON.parse(fs.readFileSync(path.join(userData, '.api-config.local.json'), 'utf8')).apiKey, '');
    console.log('桌面启动、API 配置保存、重新读取及清除验证通过。');
  } catch (error) {
    console.error(error);
    process.exitCode = 1;
  } finally {
    if (process.env.PANSHANG_KEEP_TEST_SERVER === '1' && !process.exitCode) {
      console.log('界面检查服务：http://127.0.0.1:3229/（配置目录只包含测试数据）');
      return;
    }
    vm.runInContext('configServer?.close()', context);
    if (child?.pid) spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true });
    console.log(`测试配置目录：${userData}`);
  }
})();
