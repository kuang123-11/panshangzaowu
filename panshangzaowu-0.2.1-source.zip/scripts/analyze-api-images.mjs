import sharp from 'sharp';
import { readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

const directory = path.resolve(process.argv[2] || 'outputs/api-tests-2026-10-10');
const files = await readdir(directory);
const records = [];
for (const file of files.filter((name) => name.endsWith('-透明成品.png'))) {
  const rawFile = file.replace('-透明成品.png', '-绿幕原图.png');
  if (!files.includes(rawFile)) continue;
  const original = await sharp(path.join(directory, rawFile)).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const result = await sharp(path.join(directory, file)).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  if (original.info.width !== result.info.width || original.info.height !== result.info.height) throw new Error('原图与结果尺寸不一致');
  let rawGreenPixels = 0, remainingGreenPixels = 0, transparentPixels = 0, solidPixels = 0;
  let naturalGreenPixels = 0, naturalGreenPreserved = 0;
  for (let offset = 0; offset < original.data.length; offset += 4) {
    const r = original.data[offset], g = original.data[offset + 1], b = original.data[offset + 2];
    const alpha = result.data[offset + 3];
    if (alpha === 0) transparentPixels += 1;
    if (alpha === 255) solidPixels += 1;
    if (g >= 190 && g - Math.max(r, b) >= 155 && Math.max(r, b) <= 35) {
      rawGreenPixels += 1;
      if (alpha >= 16) remainingGreenPixels += 1;
    } else if (g > r + 20 && g > b + 20 && (g < 190 || Math.max(r, b) > 35)) {
      naturalGreenPixels += 1;
      if (alpha >= 240) naturalGreenPreserved += 1;
    }
  }
  const width = result.info.width, height = result.info.height;
  const seen = new Uint8Array(width * height), queue = new Int32Array(width * height);
  const enclosedTransparentAreas = [];
  for (let start = 0; start < seen.length; start += 1) {
    if (seen[start] || result.data[start * 4 + 3] > 16) continue;
    let head = 0, tail = 1, touchesBorder = false;
    queue[0] = start; seen[start] = 1;
    while (head < tail) {
      const position = queue[head++], x = position % width, y = Math.floor(position / width);
      if (!x || !y || x === width - 1 || y === height - 1) touchesBorder = true;
      for (const neighbor of [x ? position - 1 : -1, x + 1 < width ? position + 1 : -1, y ? position - width : -1, y + 1 < height ? position + width : -1]) {
        if (neighbor < 0 || seen[neighbor] || result.data[neighbor * 4 + 3] > 16) continue;
        seen[neighbor] = 1; queue[tail++] = neighbor;
      }
    }
    if (!touchesBorder && tail >= 16) enclosedTransparentAreas.push(tail);
  }
  records.push({ file, width: result.info.width, height: result.info.height, rawGreenPixels, remainingGreenPixels, transparentPixels, solidPixels, naturalGreenPixels, naturalGreenPreserved,
    naturalGreenPreservedPercent: naturalGreenPixels ? Number((naturalGreenPreserved / naturalGreenPixels * 100).toFixed(3)) : null,
    enclosedTransparentAreas: enclosedTransparentAreas.sort((a, b) => b - a) });
}
for (const file of files.filter((name) => name.endsWith('-场景成品.png'))) {
  const result = await sharp(path.join(directory, file)).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  let transparentPixels = 0;
  for (let offset = 3; offset < result.data.length; offset += 4) if (result.data[offset] < 255) transparentPixels += 1;
  records.push({ file, width: result.info.width, height: result.info.height, transparentPixels });
}
await writeFile(path.join(directory, 'pixel-analysis.json'), JSON.stringify(records, null, 2));
console.log(JSON.stringify(records, null, 2));
