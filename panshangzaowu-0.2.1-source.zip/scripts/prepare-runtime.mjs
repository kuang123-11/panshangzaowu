import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

export function prepareRuntime(root, destination) {
  const modules = path.join(destination, 'node_modules');
  if (fs.existsSync(modules)) {
    // A previous build used a junction; unlink it without touching its target.
    if (fs.lstatSync(modules).isSymbolicLink()) fs.unlinkSync(modules);
    else fs.rmSync(modules, { recursive: true });
  }
  const visited = new Set();
  function locate(name, from) {
    let current = from;
    while (true) {
      const candidate = path.join(current, 'node_modules', name);
      if (fs.existsSync(path.join(candidate, 'package.json'))) return candidate;
      const parent = path.dirname(current);
      if (parent === current) return null;
      current = parent;
    }
  }
  function copy(name, from, optional = false) {
    const source = locate(name, from);
    if (!source) {
      if (optional) return;
      throw new Error(`缺少运行依赖：${name}`);
    }
    if (visited.has(source)) return;
    const manifest = JSON.parse(fs.readFileSync(path.join(source, 'package.json'), 'utf8'));
    if (manifest.os && !manifest.os.includes('win32') && !manifest.os.every((os) => os.startsWith('!'))) return;
    if (manifest.cpu && !manifest.cpu.includes('x64') && !manifest.cpu.every((cpu) => cpu.startsWith('!'))) return;
    visited.add(source);
    const relative = path.relative(path.join(root, 'node_modules'), source);
    if (relative.startsWith('..')) throw new Error('运行依赖超出项目目录');
    const target = path.join(modules, relative);
    const result = spawnSync('robocopy', [source, target, '/E', '/XD', 'node_modules', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP'], { windowsHide: true, stdio: 'pipe' });
    if (result.error || result.status === null || result.status > 7) throw new Error(`复制运行依赖失败：${name}`);
    for (const dependency of Object.keys(manifest.dependencies || {})) copy(dependency, source, Boolean(manifest.optionalDependencies?.[dependency]));
    for (const dependency of Object.keys(manifest.optionalDependencies || {})) copy(dependency, source, true);
  }
  copy('wrangler', root);
  console.log(`运行依赖已精简：${visited.size} 个包（仅 Windows x64）。`);
}
