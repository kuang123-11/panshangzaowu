import { spawn } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { readFile, rename, writeFile } from 'node:fs/promises';
import { createServer as createHttpServer } from 'node:http';
import { createServer } from 'node:net';
import { fileURLToPath } from 'node:url';

const port = Number(process.env.SHEJI_WEB_PORT || 3211);
const url = `http://127.0.0.1:${port}/`;
const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const configFile = fileURLToPath(new URL('../.api-config.local.json', import.meta.url));
const vinextCli = fileURLToPath(
  new URL('../node_modules/vinext/dist/cli.js', import.meta.url),
);

if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error('本地网页端口设置无效。');
  process.exit(1);
}

const portAvailable = await new Promise((resolve) => {
  const probe = createServer();
  probe.once('error', () => resolve(false));
  probe.listen(port, '127.0.0.1', () => probe.close(() => resolve(true)));
});

if (!portAvailable) {
  console.error(`无法启动网页版：${url} 已被占用。请先关闭正在运行的桌面版或旧网页。`);
  process.exit(1);
}

const configToken = randomBytes(32).toString('hex');
const configServer = createHttpServer(async (request, response) => {
  if (request.url !== '/config' || request.headers.authorization !== `Bearer ${configToken}`) {
    response.writeHead(403).end();
    return;
  }
  try {
    if (request.method === 'GET') {
      let saved = {};
      try {
        saved = JSON.parse(await readFile(configFile, 'utf8'));
      } catch (error) {
        if (error.code !== 'ENOENT') throw error;
      }
      response.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify(saved));
      return;
    }
    if (request.method === 'PUT') {
      let raw = '';
      for await (const chunk of request) {
        raw += chunk;
        if (raw.length > 16_384) throw new Error('配置内容过大');
      }
      const config = JSON.parse(raw);
      if (typeof config.apiKey !== 'string' || typeof config.model !== 'string' || typeof config.baseUrl !== 'string')
        throw new Error('配置字段无效');
      const temporaryFile = `${configFile}.${process.pid}.tmp`;
      await writeFile(temporaryFile, `${JSON.stringify(config, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
      await rename(temporaryFile, configFile);
      response.writeHead(200, { 'Content-Type': 'application/json' }).end('{}');
      return;
    }
    response.writeHead(405).end();
  } catch (error) {
    console.error('本地配置保存失败：', error.message);
    response.writeHead(500).end();
  }
});
await new Promise((resolve, reject) => {
  configServer.once('error', reject);
  configServer.listen(0, '127.0.0.1', resolve);
});
const configPort = configServer.address().port;

console.log(`盘上造物网页版正在启动：${url}`);
const server = spawn(process.execPath, [vinextCli, 'dev'], {
  cwd: projectRoot,
  env: { ...process.env, SHEJI_CONFIG_PORT: String(configPort), SHEJI_CONFIG_TOKEN: configToken },
  stdio: 'inherit',
  windowsHide: true,
});

let opened = false;
const browserTimer = setInterval(async () => {
  if (opened) return;
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(1500) });
    if (!response.ok) return;
    opened = true;
    clearInterval(browserTimer);
    const command = process.platform === 'win32' ? 'rundll32.exe' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    const args = process.platform === 'win32' ? ['url.dll,FileProtocolHandler', url] : [url];
    const browser = spawn(command, args, {
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
    });
    browser.on('error', () => console.log(`请在浏览器打开 ${url}`));
    browser.unref();
  } catch {
    // Wait until the first route has compiled and the local server is ready.
  }
}, 600);

server.on('error', (error) => {
  clearInterval(browserTimer);
  configServer.close();
  console.error(`网页版启动失败：${error.message}`);
  process.exitCode = 1;
});
server.on('exit', (code) => {
  clearInterval(browserTimer);
  configServer.close();
  process.exitCode = code ?? 1;
});
process.on('SIGINT', () => server.kill('SIGINT'));
