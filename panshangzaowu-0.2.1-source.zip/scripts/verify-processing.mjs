import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import ts from 'typescript';

const require = createRequire(import.meta.url);
function load(relative, dependencies = {}) {
  const source = readFileSync(new URL(`../${relative}`, import.meta.url), 'utf8');
  const code = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText;
  const module = { exports: {} };
  new Function('require', 'module', 'exports', code)((name) => dependencies[name] || require(name), module, module.exports);
  return module.exports;
}
const presets = load('lib/container-presets.ts');
const limits = load('lib/processing.ts');
assert.equal(limits.PROCESS_TIMEOUT_MS, 600000);
assert.equal(presets.containerPresets.filter((preset) => preset.id.startsWith('round-')).length, 1);
assert.equal(presets.getContainerPreset('round-small').id, 'round-medium');
assert.equal(presets.getContainerPreset('round-large').id, 'round-medium');
assert.equal(presets.getContainerPreset('bento-four').id, 'bento-four');
const { POST } = load('app/api/process/route.ts', {
  'next/server': { NextResponse: { json: (body, options) => Response.json(body, options) } },
  '@/lib/api-config': { readApiConfig: async () => ({ apiKey: 'test-only', baseUrl: 'http://test.local/v1', model: 'test-image' }) },
  '@/lib/container-presets': presets,
  '@/lib/optimization-strength': load('lib/optimization-strength.ts'),
  '@/lib/processing': limits,
});
const originalFetch = globalThis.fetch;
const originalTimeout = AbortSignal.timeout;
let capturedBody;
let capturedTimeout;
let timeoutTest = false;
globalThis.fetch = async (url, options) => {
  assert.equal(url, 'http://test.local/v1/images/edits');
  capturedBody = options.body;
  if (timeoutTest) throw new DOMException('test timeout', 'TimeoutError');
  return Response.json({ data: [{ b64_json: 'dGVzdA==' }] });
};
AbortSignal.timeout = (milliseconds) => { capturedTimeout = milliseconds; return originalTimeout(milliseconds); };
try {
  for (const [fileType, count, expected] of [['text/plain', 1, 400], ['image/png', 9, 400]]) {
    const form = new FormData();
    for (let index = 0; index < count; index += 1) form.append('image', new Blob(['test'], { type: fileType }), 'test.png');
    const response = await POST(new Request('http://localhost/api/process', { method: 'POST', body: form }));
    assert.equal(response.status, expected, '无效上传必须在调用图像 API 前拒绝');
  }
  const crossSite = await POST(new Request('http://localhost/api/process', { method: 'POST', headers: { Origin: 'https://example.invalid' } }));
  assert.equal(crossSite.status, 403);
  for (const preset of presets.containerPresets) {
    const form = new FormData();
    form.append('image', new Blob(['test'], { type: 'image/png' }), 'test.png');
    form.append('mode', 'material');
    form.append('containerPreset', preset.id);
    const response = await POST(new Request('http://localhost/api/process', { method: 'POST', body: form }));
    assert.equal(response.status, 200);
    assert.equal(capturedTimeout, 600000);
    const prompt = capturedBody.get('prompt');
    assert.ok(prompt.includes('#00FF00'));
    assert.ok(prompt.includes('enclosed handle holes'));
    assert.ok(!prompt.includes('#00C8FF'));
    assert.ok(prompt.includes(preset.id === 'original' ? 'Keep the original complete container' : preset.prompt));
    assert.equal(capturedBody.get('image[]').name, 'test.png');
  }
  timeoutTest = true;
  const form = new FormData();
  form.append('image', new Blob(['test'], { type: 'image/png' }), 'test.png');
  const response = await POST(new Request('http://localhost/api/process', { method: 'POST', body: form }));
  assert.match((await response.json()).error, /十分钟/);
  console.log('十分钟时限、容器去重、旧项目映射、全部素材容器指令及超时反馈验证通过（未调用真实 API）。');
} finally {
  globalThis.fetch = originalFetch;
  AbortSignal.timeout = originalTimeout;
}
