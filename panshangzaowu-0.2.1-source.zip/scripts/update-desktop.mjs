import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { prepareRuntime } from './prepare-runtime.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputs = path.join(root, 'outputs');
const staging = path.join(outputs, '.desktop-staging');
const candidate = path.join(staging, 'win-unpacked');
const release = path.join(outputs, '盘上造物');
const backup = path.join(outputs, `.desktop-backup-${Date.now()}`);
const builder = path.join(root, 'node_modules', 'electron-builder', 'cli.js');
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const packagingApp = path.join(root, '.release-app');
const temp = path.join(root, '.build-temp');
fs.mkdirSync(temp, { recursive: true });
Object.assign(process.env, {
  TEMP: temp, TMP: temp,
  XDG_CONFIG_HOME: path.join(temp, 'config'),
  npm_config_cache: path.join(temp, 'npm'),
  ELECTRON_BUILDER_CACHE: path.join(temp, 'electron-builder'),
  ELECTRON_CACHE: path.join(temp, 'electron'),
  WRANGLER_SEND_METRICS: 'false', WRANGLER_WRITE_LOGS: 'false',
  WRANGLER_LOG_PATH: path.join(temp, 'logs'),
  MINIFLARE_REGISTRY_PATH: path.join(temp, 'registry'),
  CSC_IDENTITY_AUTO_DISCOVERY: 'false',
});

function run(script, args) {
  const result = spawnSync(process.execPath, [script, ...args], {
    cwd: root,
    stdio: 'inherit',
    windowsHide: true,
  });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${path.basename(script)} 退出码 ${result.status}`);
}

if (fs.existsSync(backup)) {
  throw new Error(`发现上次更新留下的备份，请先检查，未覆盖：${backup}`);
}
fs.mkdirSync(outputs, { recursive: true });
if (fs.existsSync(staging)) fs.rmSync(staging, { recursive: true });

try {
  run(path.join(root, 'node_modules', 'typescript', 'bin', 'tsc'), ['--noEmit', '--incremental', 'false']);
  run(path.join(root, 'scripts', 'verify-processing.mjs'), []);
  run(path.join(root, 'scripts', 'verify-green-screen.mjs'), []);
  const built = path.join(root, 'dist');
  if (fs.existsSync(built)) fs.rmSync(built, { recursive: true });
  run(path.join(root, 'node_modules', 'vinext', 'dist', 'cli.js'), ['build']);
  fs.mkdirSync(packagingApp, { recursive: true });
  for (const area of ['dist', 'electron']) {
    const target = path.join(packagingApp, area);
    if (fs.existsSync(target)) fs.rmSync(target, { recursive: true });
    const copied = spawnSync('robocopy', [path.join(root, area), target, '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP'], { windowsHide: true, stdio: 'inherit' });
    if (copied.error || copied.status === null || copied.status > 7) throw new Error(`复制 ${area} 失败`);
  }
  // Client libraries are already bundled. Only Wrangler is needed at runtime.
  fs.writeFileSync(path.join(packagingApp, 'package.json'), JSON.stringify({
    name: 'panshangzaowu-local', version: packageJson.version, private: true,
    description: packageJson.description, author: packageJson.author,
    main: 'electron/main.cjs', type: 'module',
    dependencies: { wrangler: packageJson.dependencies.wrangler },
  }, null, 2));
  prepareRuntime(root, packagingApp);
  run(builder, ['--win', '--x64', '--dir', '--config.directories.app=.release-app', '--config.electronDist=node_modules/electron/dist']);
  if (!fs.existsSync(path.join(candidate, '盘上造物.exe'))) {
    throw new Error('构建目录缺少盘上造物.exe');
  }

  const usage = [
    `盘上造物 · Windows 本地版 ${packageJson.version}`,
    '',
    '启动：双击本文件夹中的“盘上造物.exe”，无需另行安装 Node.js。',
    '请保留本文件夹内的 resources、locales 等文件，不要单独移动 EXE。',
    '作者署名：寸灰。适用于 Windows 10/11 64 位。',
    '请先完整解压到有写入权限的文件夹，再运行；不要直接在压缩包内打开。',
    '首次使用请在右上角“设置 API”填写自己的地址、密钥及支持图像编辑的模型。',
    '无需登录、注册或购买点数；API 费用由你选择的服务商收取。',
    '生成图片需要联网；连接测试不生成图片。一次处理可能等待十分钟。',
    '',
    '更新：先关闭盘上造物，再在项目源码目录运行 npm run desktop:update。',
    '程序会验证新版本并更新到固定的 outputs/盘上造物 文件夹。',
    'API 设置、项目、缓存和日志保存在程序旁的 data 文件夹。密钥为本机文件，请妥善保管。',
    '更新前退出程序并备份旧版 data 文件夹；将它复制到新版程序旁即可继续使用。',
    '网页版与桌面版的数据不会自动同步；重要成品请提前导出。',
    '',
    '分享给其他人：只发送发布 ZIP，切勿发送你使用后产生的 data 文件夹，其中有个人密钥和图片。',
    '不要把源码、.env.local 或 .api-config.local.json 发给其他人。',
    '启动失败时查看 data/startup-error.log；如果端口被占用，先关闭旧版后重试。',
    '若 Windows 提示未验证发布者，本版本尚未进行商业代码签名。请核对来源和 SHA256。',
    '',
  ].join('\r\n');
  fs.writeFileSync(path.join(candidate, '使用说明.txt'), usage, 'utf8');

  run(path.join(root, 'scripts', 'verify-release.mjs'), [candidate]);
  run(path.join(root, 'scripts', 'verify-desktop.cjs'), [path.join(candidate, 'resources', 'app')]);

  if (fs.existsSync(release)) fs.renameSync(release, backup);
  try {
    fs.renameSync(candidate, release);
  } catch (error) {
    if (fs.existsSync(backup)) fs.renameSync(backup, release);
    throw error;
  }
  const archive = path.join(outputs, `盘上造物-${packageJson.version}-Windows-x64-分享包.zip`);
  if (fs.existsSync(archive)) fs.unlinkSync(archive);
  const zipped = spawnSync('powershell.exe', ['-NoProfile', '-Command', 'Add-Type -AssemblyName System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::CreateFromDirectory($env:PANSHANG_RELEASE, $env:PANSHANG_ARCHIVE, [IO.Compression.CompressionLevel]::Optimal, $true)'], { cwd: outputs, env: { ...process.env, PANSHANG_RELEASE: release, PANSHANG_ARCHIVE: archive }, stdio: 'inherit', windowsHide: true });
  if (zipped.error || zipped.status !== 0) throw new Error('压缩分享包失败');
  const hash = createHash('sha256').update(fs.readFileSync(archive)).digest('hex');
  fs.writeFileSync(`${archive}.sha256.txt`, `${hash}  ${path.basename(archive)}\n`);
  // Archive the pristine release before restoring local settings and projects.
  if (fs.existsSync(path.join(backup, 'data'))) fs.renameSync(path.join(backup, 'data'), path.join(release, 'data'));
  if (fs.existsSync(backup)) fs.rmSync(backup, { recursive: true });
  console.log(`可直接发送：${archive}`);
  console.log(`桌面版已更新：${release}`);
} finally {
  if (fs.existsSync(staging)) fs.rmSync(staging, { recursive: true });
}
