# Node runtime

Windows 打包前在本源码目录执行：

    node -e "const fs=require('node:fs');fs.mkdirSync('runtime',{recursive:true});fs.copyFileSync(process.execPath,'runtime/node.exe')"

然后执行 npm run desktop:update。运行 npm ci 所用的 Node 应为 Windows x64、22 或更高版本。源码包不携带本机可执行文件与开发依赖。
