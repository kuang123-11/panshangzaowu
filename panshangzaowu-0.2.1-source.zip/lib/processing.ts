// Shared by the browser and API route so both wait for the same per-image limit.
export const PROCESS_TIMEOUT_MS = 10 * 60 * 1000;
