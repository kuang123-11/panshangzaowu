export const optimizationStrengthProfiles = [
  {
    min: 20,
    max: 34,
    label: '轻微',
    description: '只做很轻的曝光、白平衡修正，最接近原图氛围。',
    instruction: 'Make only minimal exposure and white-balance corrections; retain the original lighting mood.',
  },
  {
    min: 35,
    max: 59,
    label: '适度',
    description: '适当改善偏暗、偏亮或偏色，通常适合日常菜品图。',
    instruction: 'Make modest exposure and white-balance corrections while retaining the original lighting mood as much as possible.',
  },
  {
    min: 60,
    max: 79,
    label: '明显',
    description: '更明显地调整整体光线与色温，原有光感可能改变。',
    instruction: 'Make more noticeable global exposure and white-balance corrections; the original lighting mood may change, but food appearance must remain natural.',
  },
  {
    min: 80,
    max: 100,
    label: '较强',
    description: '优先纠正明显的明暗与偏色；更可能偏离原图光感。',
    instruction: 'Prioritize correcting strong exposure and white-balance issues through global lighting adjustments; the original lighting mood may change substantially, but do not alter food texture, shape, or saturation.',
  },
] as const;

export function getOptimizationStrengthProfile(value: number) {
  const strength = Number.isFinite(value) ? Math.min(100, Math.max(20, value)) : 35;
  return optimizationStrengthProfiles.find((profile) => strength <= profile.max) ?? optimizationStrengthProfiles[1];
}
