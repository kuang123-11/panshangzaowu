export const containerPresets = [
  { id: 'original', group: '原容器', name: '保留原容器', detail: '沿用原图中的盘、碗或盒', prompt: '' },
  { id: 'round-medium', group: '餐盘', name: '圆形餐盘', detail: '白瓷浅口 · 通用单菜', prompt: 'a complete round white ceramic dinner plate with a gently raised rim, sized naturally for the food portion' },
  { id: 'oval-platter', group: '餐盘', name: '椭圆鱼盘', detail: '修长椭圆 · 整鱼和长条菜', prompt: 'a complete elongated oval white ceramic fish platter, sized naturally for the food portion' },
  { id: 'square-plate', group: '餐盘', name: '方形平盘', detail: '柔和方角 · 精致摆盘', prompt: 'a complete square white ceramic plate with softly rounded corners, sized naturally for the food portion' },
  { id: 'leaf-plate', group: '餐盘', name: '叶形餐盘', detail: '青瓷叶形 · 创意菜品', prompt: 'a complete celadon ceramic leaf-shaped plate with a pointed tip and shallow curved rim, sized naturally for the food portion' },
  { id: 'deep-bowl', group: '碗', name: '深口圆碗', detail: '白瓷深碗 · 汤汁和炖菜', prompt: 'a complete deep round white ceramic bowl with a solid continuous upper rim, sized naturally for the food portion' },
  { id: 'noodle-bowl', group: '碗', name: '斗笠面碗', detail: '宽口收底 · 面条和米粉', prompt: 'a complete flared conical ceramic noodle bowl with a wide opening, tapered narrow foot and visible continuous rim' },
  { id: 'rect-tray', group: '托盘', name: '长方托盘', detail: '浅口长方 · 烧烤和拼盘', prompt: 'a complete shallow rectangular white serving tray with rounded corners, sized naturally for the food portion' },
  { id: 'wood-board', group: '托盘', name: '木质餐板', detail: '带柄木板 · 烤肉和小食', prompt: 'a complete natural wooden serving board with a short handle, visible wood grain and no extra props' },
  { id: 'slate-board', group: '托盘', name: '石板餐台', detail: '深色石板 · 冷盘和前菜', prompt: 'a complete flat rectangular dark slate serving board with a subtly irregular stone edge and no extra props' },
  { id: 'bento-single', group: '餐盒', name: '单格餐盒', detail: '无盖单格 · 外带主食', prompt: 'a complete single-compartment rectangular takeaway meal box, matte ivory food-safe material, without lid' },
  { id: 'bento-three', group: '餐盒', name: '分格餐盒', detail: '一主两配 · 分隔盛装', prompt: 'a complete three-compartment rectangular bento box, matte ivory food-safe material, one large main compartment and two smaller side compartments, no lid' },
  { id: 'bento-four', group: '餐盒', name: '四格餐盒', detail: '四个分区 · 多菜套餐', prompt: 'a complete four-compartment rectangular bento box, matte ivory food-safe material, four clearly separated compartments, no lid' },
  { id: 'clay-pot', group: '特色容器', name: '砂锅', detail: '双耳陶锅 · 煲仔和炖菜', prompt: 'a complete round earthenware clay pot with two small side handles, thick glazed rim, no lid' },
  { id: 'iron-skillet', group: '特色容器', name: '铸铁煎锅', detail: '长柄铁锅 · 煎烤热菜', prompt: 'a complete shallow black cast iron skillet with one long handle, include the entire handle in frame, no lid' },
  { id: 'bamboo-steamer', group: '特色容器', name: '竹蒸笼', detail: '竹编筒身 · 点心和蒸菜', prompt: 'a complete round bamboo steamer basket with a visible woven base and tall bamboo rim, no lid' },
  { id: 'glass-cup', group: '特色容器', name: '玻璃甜品杯', detail: '透明高脚 · 甜品和小食', prompt: 'a complete clear glass dessert coupe with a short stem and round foot, visible glass rim and natural reflections' },
] as const;

export type ContainerPresetId = (typeof containerPresets)[number]['id'];

export function getContainerPreset(id: string) {
  const normalizedId = id === 'round-small' || id === 'round-large' ? 'round-medium' : id;
  return containerPresets.find((preset) => preset.id === normalizedId) || containerPresets[0];
}
