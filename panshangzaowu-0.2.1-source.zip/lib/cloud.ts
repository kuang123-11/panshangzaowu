'use client';

// 盘上造物 · 云服务客户端初始化（WorkBuddy Cloud Service）
// 提供账号认证、点数数据库能力。endpoint/publishableKey 来自开通时下发的 publicConfig。

import { createWorkBuddyCloud } from '@tencent-ai/workbuddy-cloud-sdk';

// publicConfig 由 workbuddy_cloud_service 开通时下发
const publicConfig = {
  endpoint: 'https://panshangzaowu.app.workbuddy.host',
  oauthRelayBaseUrl: 'https://www.workbuddy.cn/v2/as/genie-baas/oauth',
  publishableKey: 'wbpk_YnX1zgCTtCpZa1NFBsUDYW_wByTqrmEcLvFptmOoEA7QSiVigZ32waB',
};

export const cloud = createWorkBuddyCloud({
  endpoint: publicConfig.endpoint,
  oauthRelayBaseUrl: publicConfig.oauthRelayBaseUrl,
  publishableKey: publicConfig.publishableKey,
});

export type PointAccount = {
  id: number;
  points: number;
  trial_used: number;
};

// 类型化 RPC 封装：SDK 未提供 schema 泛型时，rpc 的参数/返回类型推断为 never/undefined。
// 这里统一收口，避免调用处反复断言。
export async function rpc<T>(fn: string, args?: Record<string, unknown>): Promise<{ data: T[] | null; error: { message?: string } | null }> {
  const client = cloud.database as unknown as {
    rpc: (fn: string, args?: Record<string, unknown>) => Promise<{ data: T[] | null; error: { message?: string } | null }>;
  };
  return client.rpc(fn, args);
}
