export type ApiConfig = {
  apiKey: string;
  baseUrl: string;
  model: string;
};

function configServiceUrl() {
  const port = process.env.SHEJI_CONFIG_PORT;
  return port ? `http://127.0.0.1:${port}/config` : null;
}

async function requestConfig(method: 'GET' | 'PUT', config?: ApiConfig): Promise<Partial<ApiConfig>> {
  const url = configServiceUrl();
  const token = process.env.SHEJI_CONFIG_TOKEN;
  if (!url || !token) {
    if (method === 'GET') return {};
    throw new Error('本地配置服务未启动，请关闭程序后重新打开最新版本。');
  }
  const response = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      ...(config ? { 'Content-Type': 'application/json' } : {}),
    },
    body: config ? JSON.stringify(config) : undefined,
  });
  if (!response.ok) throw new Error(`本地配置服务返回 HTTP ${response.status}`);
  return response.json() as Promise<Partial<ApiConfig>>;
}

export async function readApiConfig(): Promise<ApiConfig> {
  const saved = await requestConfig('GET');
  return {
    apiKey: typeof saved.apiKey === 'string' ? saved.apiKey : process.env.OPENAI_API_KEY || '',
    baseUrl: saved.baseUrl || process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1',
    model: saved.model || process.env.OPENAI_IMAGE_MODEL || 'gpt-image-2',
  };
}

export async function writeApiConfig(config: ApiConfig) {
  await requestConfig('PUT', config);
}
