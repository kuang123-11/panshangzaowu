// Key a saturated green matte, including regions enclosed by the foreground.
// Interior seeds deliberately require a much purer green than ordinary foliage.
export function removeGreenScreen(pixels: Uint8ClampedArray, width: number, height: number, required = false) {
  const count = width * height;
  if (width < 1 || height < 1 || pixels.length !== count * 4) throw new Error('图片尺寸无效');
  const source = new Uint8ClampedArray(pixels);
  const colors = new Map<string, { count: number; r: number; g: number; b: number }>();
  let opaqueSamples = 0;
  let greenSamples = 0;
  let hasTransparency = false;
  for (let offset = 3; offset < pixels.length; offset += 4) {
    if (pixels[offset] < 250) { hasTransparency = true; break; }
  }
  const sample = (position: number) => {
    const offset = position * 4;
    if (source[offset + 3] < 240) return;
    opaqueSamples += 1;
    const r = source[offset], g = source[offset + 1], b = source[offset + 2];
    if (g < 170 || g - Math.max(r, b) < 85 || Math.max(r, b) > 100) return;
    greenSamples += 1;
    const key = `${r >> 4},${g >> 4},${b >> 4}`;
    const value = colors.get(key) || { count: 0, r: 0, g: 0, b: 0 };
    value.count += 1; value.r += r; value.g += g; value.b += b;
    colors.set(key, value);
  };
  const step = Math.max(1, Math.floor(Math.max(width, height) / 500));
  for (let x = 0; x < width; x += step) { sample(x); sample((height - 1) * width + x); }
  for (let y = 0; y < height; y += step) { sample(y * width); sample(y * width + width - 1); }
  const mainColor = [...colors.values()].sort((a, b) => b.count - a.count)[0];
  if (!mainColor || greenSamples < opaqueSamples * 0.25) {
    if (required && !hasTransparency) throw new Error('图像服务没有生成纯绿幕背景；为保护菜品和容器，未自动去背。请检查返回图片后再决定是否重试。');
    return false;
  }
  const background = [mainColor.r / mainColor.count, mainColor.g / mainColor.count, mainColor.b / mainColor.count];
  const distance = (offset: number) => Math.hypot(source[offset] - background[0], source[offset + 1] - background[1], source[offset + 2] - background[2]);
  const isMatte = (offset: number, strict = false) => {
    const r = source[offset], g = source[offset + 1], b = source[offset + 2];
    return source[offset + 3] > 0 && g >= (strict ? 190 : 145)
      && g - Math.max(r, b) >= (strict ? 155 : 95)
      && (!strict || Math.max(r, b) <= 35)
      && distance(offset) <= (strict ? 65 : 75);
  };
  const mask = new Uint8Array(count);
  const queue = new Int32Array(count);
  let head = 0, tail = 0;
  const enqueue = (position: number) => {
    if (mask[position] || !isMatte(position * 4)) return;
    mask[position] = 1;
    queue[tail++] = position;
  };
  for (let x = 0; x < width; x += 1) { enqueue(x); enqueue((height - 1) * width + x); }
  for (let y = 0; y < height; y += 1) { enqueue(y * width); enqueue(y * width + width - 1); }
  // Unlike an exterior-only flood fill, these seeds reach handle holes and gaps.
  for (let position = 0; position < count; position += 1) {
    if (isMatte(position * 4, true)) enqueue(position);
  }
  while (head < tail) {
    const position = queue[head++];
    const x = position % width, y = Math.floor(position / width);
    pixels[position * 4 + 3] = 0;
    if (x > 0) enqueue(position - 1);
    if (x + 1 < width) enqueue(position + 1);
    if (y > 0) enqueue(position - width);
    if (y + 1 < height) enqueue(position + width);
  }
  // Recover antialiased foreground edges from the measured green matte and a
  // nearby solid foreground color, rather than merely deleting tinted pixels.
  for (let position = 0; position < count; position += 1) {
    const offset = position * 4;
    if (mask[position] || !source[offset + 3] || source[offset + 1] - Math.max(source[offset], source[offset + 2]) < 14) continue;
    const x = position % width, y = Math.floor(position / width);
    let touchesMatte = false;
    for (let dy = -1; dy <= 1 && !touchesMatte; dy += 1) {
      for (let dx = -1; dx <= 1; dx += 1) {
        const nx = x + dx, ny = y + dy;
        if (nx >= 0 && nx < width && ny >= 0 && ny < height && mask[ny * width + nx]) { touchesMatte = true; break; }
      }
    }
    if (!touchesMatte) continue;
    let reference = -1, nearest = Infinity;
    for (let dy = -4; dy <= 4; dy += 1) {
      for (let dx = -4; dx <= 4; dx += 1) {
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
        const candidatePosition = ny * width + nx, candidate = candidatePosition * 4;
        if (mask[candidatePosition] || source[candidate + 3] < 240 || source[candidate + 1] - Math.max(source[candidate], source[candidate + 2]) > 85 || distance(candidate) < 115) continue;
        const spatialDistance = dx * dx + dy * dy;
        if (spatialDistance < nearest) { nearest = spatialDistance; reference = candidate; }
      }
    }
    if (reference < 0) continue;
    let dot = 0, norm = 0;
    for (let channel = 0; channel < 3; channel += 1) {
      const direction = source[reference + channel] - background[channel];
      dot += (source[offset + channel] - background[channel]) * direction;
      norm += direction * direction;
    }
    const alpha = Math.max(0, Math.min(1, dot / Math.max(1, norm)));
    let error = 0;
    for (let channel = 0; channel < 3; channel += 1) {
      const expected = background[channel] + alpha * (source[reference + channel] - background[channel]);
      error += (source[offset + channel] - expected) ** 2;
    }
    if (Math.sqrt(error) > 30 || alpha < 0.03 || alpha > 0.98) continue;
    for (let channel = 0; channel < 3; channel += 1) pixels[offset + channel] = Math.max(0, Math.min(255, (source[offset + channel] - (1 - alpha) * background[channel]) / alpha));
    pixels[offset + 3] = Math.round(source[offset + 3] * alpha);
  }
  return true;
}
