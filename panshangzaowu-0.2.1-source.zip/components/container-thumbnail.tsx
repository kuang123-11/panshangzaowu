type ContainerThumbnailProps = {
  id: string;
  name: string;
};

export function ContainerThumbnail({ id, name }: ContainerThumbnailProps) {
  const rim = '#aba79e';
  const inside = '#f3f1ec';
  const outer = '#fffefa';
  const radius = ['round-small', 'round-medium', 'round-large'].includes(id) ? 27 : undefined;

  return (
    <svg viewBox="0 0 120 80" role="img" aria-label={`${name}示意图`} className="h-[72px] w-full rounded-lg bg-[#eae8e2]">
      <ellipse cx="60" cy="66" rx="41" ry="7" fill="#aaa59a" opacity=".16" />
      {radius ? (
        <>
          <circle cx="60" cy="39" r={radius} fill={outer} stroke={rim} strokeWidth="1.5" />
          <circle cx="60" cy="39" r={radius - 5} fill={inside} stroke="#d6d1c8" strokeWidth="1.3" />
        </>
      ) : id === 'original' ? (
        <>
          <circle cx="60" cy="39" r="27" fill={outer} stroke={rim} strokeDasharray="3 3" strokeWidth="1.5" />
          <circle cx="60" cy="39" r="21" fill={inside} stroke="#d6d1c8" strokeWidth="1.2" />
          <text x="60" y="44" textAnchor="middle" fontSize="13" fill="#77746e">原图</text>
        </>
      ) : id === 'oval-platter' ? (
        <>
          <ellipse cx="60" cy="39" rx="47" ry="23" fill={outer} stroke={rim} strokeWidth="1.5" />
          <ellipse cx="60" cy="39" rx="40" ry="17" fill={inside} stroke="#d6d1c8" strokeWidth="1.2" />
        </>
      ) : id === 'square-plate' ? (
        <>
          <rect x="31" y="10" width="58" height="58" rx="8" fill={outer} stroke={rim} strokeWidth="1.5" />
          <rect x="37" y="16" width="46" height="46" rx="6" fill={inside} stroke="#d6d1c8" strokeWidth="1.2" />
        </>
      ) : id === 'leaf-plate' ? (
        <><path d="M17 49Q33 7 105 18Q94 66 17 49Z" fill="#d5e5d6" stroke="#869b88" strokeWidth="1.5" /><path d="M25 46Q58 30 97 22" fill="none" stroke="#a5b9a6" strokeWidth="1.5" /></>
      ) : id === 'noodle-bowl' ? (
        <><path d="M19 28L42 64H78L101 28" fill={outer} stroke={rim} strokeWidth="1.5" /><ellipse cx="60" cy="28" rx="41" ry="17" fill={inside} stroke={rim} strokeWidth="2" /><ellipse cx="60" cy="29" rx="33" ry="11" fill="#ddd8cc" /></>
      ) : id === 'clay-pot' ? (
        <><rect x="12" y="32" width="96" height="16" rx="7" fill="#a07851" /><ellipse cx="60" cy="43" rx="35" ry="25" fill="#805636" /><ellipse cx="60" cy="33" rx="35" ry="21" fill="#c79d6d" stroke="#805636" strokeWidth="3" /><ellipse cx="60" cy="33" rx="27" ry="15" fill="#ede0c5" /></>
      ) : id === 'iron-skillet' ? (
        <><path d="M75 36H111V45H75Z" fill="#363839" /><circle cx="45" cy="40" r="30" fill="#363839" /><circle cx="45" cy="40" r="24" fill="#5b5d5e" stroke="#1f2223" strokeWidth="2" /></>
      ) : id === 'bamboo-steamer' ? (
        <><path d="M25 29V53C25 76 95 76 95 53V29" fill="#c9a46d" stroke="#977843" strokeWidth="2" /><ellipse cx="60" cy="29" rx="35" ry="22" fill="#e8d2a9" stroke="#977843" strokeWidth="3" /><path d="M37 14L83 44M29 23L75 53M48 9L93 39M36 43L77 13M29 34L63 10M49 50L89 22" stroke="#c4a26f" strokeWidth="2" /></>
      ) : id === 'glass-cup' ? (
        <><path d="M29 20Q30 50 60 50Q90 50 91 20M60 50V65" fill="#edf7f9" fillOpacity=".7" stroke="#86a5ad" strokeWidth="2" /><ellipse cx="60" cy="20" rx="31" ry="10" fill="#f8fdff" stroke="#86a5ad" strokeWidth="1.5" /><ellipse cx="60" cy="67" rx="18" ry="4" fill="#e5f0f2" stroke="#86a5ad" strokeWidth="1.5" /></>
      ) : id === 'wood-board' ? (
        <><path d="M14 17H83Q89 17 89 23V32H108V46H89V57Q89 63 83 63H14Z" fill="#c49b6b" stroke="#987143" strokeWidth="1.5" /><path d="M20 27H80M20 39H76M20 53H80" stroke="#ad8453" strokeWidth="2" /><circle cx="102" cy="39" r="3" fill="#eae8e2" /></>
      ) : id === 'slate-board' ? (
        <><path d="M13 19L102 16L107 59L18 63L12 48Z" fill="#444b50" stroke="#252b30" strokeWidth="2" /><path d="M19 23L97 20M22 57L100 55" stroke="#687177" strokeWidth="1" /></>
      ) : id === 'deep-bowl' ? (
        <>
          <circle cx="60" cy="39" r="31" fill="#d1ccc2" stroke={rim} strokeWidth="1.5" />
          <circle cx="60" cy="39" r="26" fill={outer} stroke="#c3beb4" strokeWidth="1.5" />
          <circle cx="60" cy="39" r="18" fill={inside} stroke="#d6d1c8" strokeWidth="1.2" />
        </>
      ) : (
        <>
          <rect x={id === 'rect-tray' ? 12 : 18} y={id === 'rect-tray' ? 17 : 13} width={id === 'rect-tray' ? 96 : 84} height={id === 'rect-tray' ? 44 : 52} rx={id === 'rect-tray' ? 9 : 7} fill={outer} stroke={rim} strokeWidth="1.5" />
          <rect x={id === 'rect-tray' ? 18 : 23} y={id === 'rect-tray' ? 22 : 18} width={id === 'rect-tray' ? 84 : 74} height={id === 'rect-tray' ? 34 : 42} rx="5" fill={inside} stroke="#d6d1c8" strokeWidth="1.2" />
          {id === 'bento-three' && (
            <>
              <path d="M68 18v42M68 39h29" stroke={rim} strokeWidth="2.5" />
              <path d="M66 18v42M68 37h29" stroke="#fffefa" strokeWidth="1" />
            </>
          )}
          {id === 'bento-four' && (
            <>
              <path d="M60 18v42M23 39h74" stroke={rim} strokeWidth="2.5" />
              <path d="M58 18v42M23 37h74" stroke="#fffefa" strokeWidth="1" />
            </>
          )}
        </>
      )}
    </svg>
  );
}
