'use client';

// 盘上造物 · 账户组件（手机号登录 / 点数余额 / 兑换码充值 / 记录）
// 基于 WorkBuddy 云服务：认证用手机号短信验证码，点数用云数据库

import { useCallback, useEffect, useState } from 'react';
import { cloud, rpc, type PointAccount } from '@/lib/cloud';

type Props = {
  open: boolean;
  onClose: () => void;
  onSignedIn: (points: number) => void;
  onSignedOut: () => void;
};

type LogRow = { id: number; delta: number; balance_after: number; reason: string; ref?: string; created_at: string };

const reasonLabel: Record<string, string> = {
  register: '注册赠送',
  redeem: '兑换码充值',
  generate: '生成图片',
  admin: '人工调整',
};

export default function AccountPanel({ open, onClose, onSignedIn, onSignedOut }: Props) {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [pendingOtp, setPendingOtp] = useState<{ phone: string; verificationId: string; isExistingUser: boolean } | null>(null);
  const [countdown, setCountdown] = useState(0);
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'info' | 'success' | 'error'>('info');
  const [busy, setBusy] = useState(false);

  const [signedIn, setSignedIn] = useState(false);
  const [account, setAccount] = useState<PointAccount | null>(null);
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [redeemCode, setRedeemCode] = useState('');

  // 倒计时
  useEffect(() => {
    if (countdown <= 0) return;
    const t = window.setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => window.clearTimeout(t);
  }, [countdown]);

  // 打开时检查登录态
  const loadState = useCallback(async () => {
    const { data: session } = await cloud.auth.getSession();
    if (session) {
      setSignedIn(true);
      const acc = (await rpc<PointAccount>('get_or_create_account')).data;
      if (acc && acc.length > 0) {
        setAccount(acc[0]);
        onSignedIn(acc[0].points);
      }
      const { data: logRows } = await cloud.database
        .from('point_logs')
        .select('id, delta, balance_after, reason, ref, created_at')
        .order('created_at', { ascending: false })
        .limit(50);
      setLogs((logRows || []) as unknown as LogRow[]);
    }
  }, [onSignedIn]);

  useEffect(() => {
    if (open) void loadState();
  }, [open, loadState]);

  if (!open) return null;

  const onPhoneInput = (v: string) => {
    setPhone(v);
    setPhoneError('');
  };

  const sendCode = async () => {
    if (!/^1\d{10}$/.test(phone)) {
      setPhoneError('请输入正确的 11 位手机号');
      return;
    }
    setBusy(true);
    setMessage('');
    const sent = await cloud.auth.sendOtp({ phone });
    setBusy(false);
    if (sent.error) {
      setMessage(sent.error.message || '发送失败，请重试');
      setStatus('error');
      return;
    }
    setPendingOtp({ phone, verificationId: sent.data.verificationId, isExistingUser: sent.data.isExistingUser });
    setCountdown(60);
    setMessage('验证码已发送，请注意查收短信。');
    setStatus('success');
  };

  const submitLogin = async () => {
    if (!pendingOtp || pendingOtp.phone !== phone) {
      setMessage('请先获取验证码。');
      setStatus('error');
      return;
    }
    if (!code.trim()) {
      setMessage('请输入验证码。');
      setStatus('error');
      return;
    }
    setBusy(true);
    setMessage('');
    const completed = await cloud.auth.verifyOtp({
      phone: pendingOtp.phone,
      verificationId: pendingOtp.verificationId,
      isExistingUser: pendingOtp.isExistingUser,
      token: code.trim(),
    });
    setBusy(false);
    if (completed.error) {
      setMessage(completed.error.message || '验证码错误，请重试');
      setStatus('error');
      return;
    }
    setPendingOtp(null);
    await loadState();
  };

  const doRedeem = async () => {
    const normalized = redeemCode.trim().toUpperCase().replace(/\s+/g, '');
    if (!normalized) return;
    setBusy(true);
    setMessage('');
    try {
      const { data, error } = await rpc<{ points: number; added: number }>('redeem_code', { p_code: normalized });
      if (error) {
        const msg = error.message || '';
        setMessage(
          msg.includes('CODE_USED') ? '该兑换码已被使用。'
          : msg.includes('CODE_NOT_FOUND') ? '兑换码无效，请核对后重试。'
          : msg.includes('INVALID_CODE') ? '兑换码格式不正确。'
          : '兑换失败，请稍后重试。',
        );
        setStatus('error');
        return;
      }
      const row = data?.[0] as unknown as { points: number; added: number } | undefined;
      if (row) {
        setMessage(`兑换成功，到账 ${row.added} 点，当前余额 ${row.points} 点。`);
        setStatus('success');
        setRedeemCode('');
        onSignedIn(row.points);
        await loadState();
      }
    } finally {
      setBusy(false);
    }
  };

  const doLogout = async () => {
    await cloud.auth.signOut();
    setSignedIn(false);
    setAccount(null);
    setLogs([]);
    onSignedOut();
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4" onClick={onClose}>
      <div
        className="w-full max-w-md overflow-hidden rounded-2xl border border-black/10 bg-white shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {!signedIn ? (
          <>
            <div className="flex items-center justify-between border-b border-black/10 px-5 py-4">
              <h2 className="text-base font-semibold">登录盘上造物</h2>
              <button onClick={onClose} className="text-black/45 hover:text-black">✕</button>
            </div>
            <div className="space-y-4 p-5">
              <p className="text-sm text-black/60">使用手机号登录，注册即赠送 3 次免费试用。</p>
              <div className="space-y-3">
                <div>
                  <input
                    value={phone}
                    onChange={(e) => onPhoneInput(e.target.value)}
                    placeholder="手机号"
                    inputMode="numeric"
                    maxLength={11}
                    className="h-11 w-full rounded-xl border border-black/10 px-3 text-sm outline-none focus:ring-2 focus:ring-black/10"
                  />
                  {phoneError && <p className="mt-1 text-xs text-red-500">{phoneError}</p>}
                </div>
                <div className="flex gap-2">
                  <input
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="短信验证码"
                    inputMode="numeric"
                    maxLength={6}
                    className="h-11 flex-1 rounded-xl border border-black/10 px-3 text-sm outline-none focus:ring-2 focus:ring-black/10"
                    onKeyDown={(e) => e.key === 'Enter' && void submitLogin()}
                  />
                  <button
                    type="button"
                    disabled={busy || countdown > 0}
                    onClick={() => void sendCode()}
                    className="h-11 shrink-0 rounded-xl border border-black/15 px-3 text-sm font-medium disabled:opacity-40"
                  >
                    {countdown > 0 ? `${countdown}s` : '获取验证码'}
                  </button>
                </div>
              </div>
              {message && <p className={`text-xs ${status === 'error' ? 'text-red-500' : 'text-[#79b900]'}`}>{message}</p>}
              <button
                disabled={busy}
                onClick={() => void submitLogin()}
                className="h-11 w-full rounded-xl bg-black text-sm font-semibold text-white disabled:opacity-50"
              >
                {busy ? '请稍候…' : '登录 / 注册'}
              </button>
              <p className="text-center text-xs text-black/40">未注册的手机号将自动创建账号</p>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center justify-between border-b border-black/10 px-5 py-4">
              <h2 className="text-base font-semibold">我的账户</h2>
              <button onClick={onClose} className="text-black/45 hover:text-black">✕</button>
            </div>
            <div className="space-y-4 p-5">
              <div className="flex items-center justify-between rounded-2xl bg-[#d9ff43] px-4 py-5">
                <div>
                  <p className="text-xs text-black/60">已登录</p>
                  <p className="text-3xl font-bold tracking-tight">
                    {account?.points ?? 0}
                    <span className="text-sm font-medium text-black/60"> 点</span>
                  </p>
                  <p className="mt-1 text-xs text-black/50">每生成 1 张图片消耗 1 点</p>
                </div>
                <button onClick={() => void doLogout()} className="rounded-lg border border-black/15 px-3 py-1.5 text-xs hover:bg-black/[.04]">退出登录</button>
              </div>

              <div>
                <p className="mb-2 text-sm font-semibold">充值套餐</p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-xl border border-black/10 p-3 text-center">
                    <p className="text-lg font-bold">20<span className="text-xs font-normal text-black/50"> 点</span></p>
                    <p className="text-xs text-black/50">20 张 · ¥9.9</p>
                  </div>
                  <div className="rounded-xl border border-black/10 p-3 text-center">
                    <p className="text-lg font-bold">80<span className="text-xs font-normal text-black/50"> 点</span></p>
                    <p className="text-xs text-black/50">80 张 · ¥29.9</p>
                  </div>
                </div>
                <p className="mt-2 text-xs text-black/45">联系客服付款后获取兑换码，在下方兑换。</p>
              </div>

              <div>
                <p className="mb-2 text-sm font-semibold">兑换码充值</p>
                <div className="flex gap-2">
                  <input
                    value={redeemCode}
                    onChange={(e) => setRedeemCode(e.target.value)}
                    placeholder="输入兑换码，如 PZ-XXXX-XXXX-XXXX"
                    className="h-11 flex-1 rounded-xl border border-black/10 px-3 text-sm outline-none focus:ring-2 focus:ring-black/10"
                  />
                  <button
                    disabled={busy || !redeemCode.trim()}
                    onClick={() => void doRedeem()}
                    className="h-11 rounded-xl bg-black px-4 text-sm font-semibold text-white disabled:opacity-50"
                  >
                    兑换
                  </button>
                </div>
              </div>

              {message && <p className={`text-xs ${status === 'error' ? 'text-red-500' : 'text-[#79b900]'}`}>{message}</p>}

              {logs.length > 0 && (
                <div>
                  <p className="mb-2 text-sm font-semibold">最近记录</p>
                  <div className="max-h-40 space-y-1 overflow-auto rounded-xl bg-black/[.03] p-2">
                    {logs.map((log) => (
                      <div key={log.id} className="flex items-center justify-between text-xs">
                        <span className="text-black/60">{reasonLabel[log.reason] || log.reason}</span>
                        <span className={log.delta > 0 ? 'text-[#79b900]' : 'text-black/45'}>
                          {log.delta > 0 ? '+' : ''}{log.delta} 点（余 {log.balance_after}）
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
