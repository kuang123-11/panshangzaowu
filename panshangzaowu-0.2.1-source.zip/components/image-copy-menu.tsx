'use client';

import type { ReactNode } from 'react';
import { Copy } from 'lucide-react';
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from '@/components/ui/context-menu';

export async function copyImageToClipboard(src: string) {
  const png = fetch(src).then(async (response) => {
    if (!response.ok) throw new Error('读取图片失败');
    const blob = await response.blob();
    if (blob.type === 'image/png') return blob;
    const bitmap = await createImageBitmap(blob);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const context = canvas.getContext('2d');
      if (!context) throw new Error('无法转换图片');
      context.drawImage(bitmap, 0, 0);
      return await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error('图片转换失败')), 'image/png'));
    } finally {
      bitmap.close();
    }
  });
  await navigator.clipboard.write([new ClipboardItem({ 'image/png': png })]);
}

export function ImageCopyMenu({ src, name, onMessage, children, className }: {
  src: string;
  name: string;
  onMessage: (message: string) => void;
  children: ReactNode;
  className?: string;
}) {
  return (
    <ContextMenu>
      <ContextMenuTrigger render={<div />} className={className}>
        {children}
      </ContextMenuTrigger>
      <ContextMenuContent>
        <ContextMenuItem onClick={() => {
          void copyImageToClipboard(src).then(() => onMessage(`${name}已复制，可直接粘贴。`)).catch(() => onMessage('复制图片失败，请使用下载按钮保存图片。'));
        }}>
          <Copy className="h-4 w-4" />复制图片
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}
