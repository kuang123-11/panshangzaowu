const { app, BrowserWindow, dialog, shell } = require('electron');
const { spawn, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const http = require('node:http');
const net = require('node:net');
const path = require('node:path');
const { randomBytes } = require('node:crypto');

const PORT = 3210;
let serverProcess = null;
let mainWindow = null;
let serverError = '';
let configServer = null;
let quitting = false;

// Keep portable editions self-contained and keep development checks off C:.
const dataDirectory = process.env.PANSHANG_DATA_DIR || (app.isPackaged
  ? path.join(path.dirname(process.execPath), 'data')
  : path.join(app.getAppPath(), '.desktop-data'));
fs.mkdirSync(dataDirectory, { recursive: true });
app.setPath('userData', dataDirectory);
app.setPath('sessionData', path.join(dataDirectory, 'browser'));
for (const name of ['temp', 'runtime']) fs.mkdirSync(path.join(dataDirectory, name), { recursive: true });
app.setPath('temp', path.join(dataDirectory, 'temp'));
const hasLock = app.requestSingleInstanceLock();
if (!hasLock) app.quit();
app.on('second-instance', () => {
  if (mainWindow?.isMinimized()) mainWindow.restore();
  mainWindow?.show();
  mainWindow?.focus();
});

async function startConfigServer() {
  const configFile = path.join(app.getPath('userData'), '.api-config.local.json');
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
  const token = randomBytes(32).toString('hex');
  configServer = http.createServer(async (request, response) => {
    if (request.url !== '/config' || request.headers.authorization !== `Bearer ${token}`) {
      response.writeHead(403).end();
      return;
    }
    try {
      if (request.method === 'GET') {
        const saved = fs.existsSync(configFile) ? JSON.parse(fs.readFileSync(configFile, 'utf8')) : {};
        response.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify(saved));
      } else if (request.method === 'PUT') {
        let raw = '';
        for await (const chunk of request) {
          raw += chunk;
          if (raw.length > 16384) throw new Error('配置内容过大');
        }
        const config = JSON.parse(raw);
        if (['apiKey', 'baseUrl', 'model'].some((key) => typeof config[key] !== 'string')) throw new Error('配置字段无效');
        const temporary = `${configFile}.tmp`;
        fs.writeFileSync(temporary, JSON.stringify(config, null, 2), { mode: 0o600 });
        fs.renameSync(temporary, configFile);
        response.writeHead(200, { 'Content-Type': 'application/json' }).end('{}');
      } else response.writeHead(405).end();
    } catch {
      response.writeHead(500).end();
    }
  });
  await new Promise((resolve, reject) => {
    configServer.once('error', reject);
    configServer.listen(0, '127.0.0.1', resolve);
  });
  return { SHEJI_CONFIG_PORT: String(configServer.address().port), SHEJI_CONFIG_TOKEN: token };
}

function recordStartupError(message) {
  serverError = message;
  try {
    fs.mkdirSync(app.getPath('userData'), { recursive: true });
    fs.appendFileSync(
      path.join(app.getPath('userData'), 'startup-error.log'),
      `${new Date().toISOString()} ${message}\n`,
      'utf8',
    );
  } catch {
    // The dialog below still reports the error if a log cannot be written.
  }
}

function appRoot() {
  return app.getAppPath();
}

function assertPortAvailable() {
  return new Promise((resolve, reject) => {
    const probe = net.createServer();
    probe.once('error', () =>
      reject(new Error('旧版盘上造物或其他程序仍在运行。请先关闭旧版，再打开新版。')),
    );
    probe.listen(PORT, '127.0.0.1', () => probe.close(resolve));
  });
}

function startServer(bindings) {
  const root = appRoot();
  const wranglerCli = path.join(root, 'node_modules', 'wrangler', 'bin', 'wrangler.js');
  const originalConfig = path.join(root, 'dist', 'server', 'wrangler.json');
  const config = path.join(app.getPath('userData'), 'desktop-server.json');
  const settings = JSON.parse(fs.readFileSync(originalConfig, 'utf8'));
  settings.main = path.resolve(path.dirname(originalConfig), settings.main);
  settings.assets.directory = path.resolve(path.dirname(originalConfig), settings.assets.directory);
  settings.vars = { ...settings.vars, ...bindings };
  fs.writeFileSync(config, JSON.stringify(settings));
  const nodeBinary = app.isPackaged
    ? path.join(process.resourcesPath, 'runtime', 'node.exe')
    : 'node';
  serverProcess = spawn(
    nodeBinary,
    [wranglerCli, 'dev', '--config', config, '--port', String(PORT), '--ip', '127.0.0.1'],
    {
      cwd: dataDirectory,
      windowsHide: true,
      env: {
        ...process.env,
        NODE_ENV: 'production',
        NO_COLOR: '1',
        TEMP: path.join(dataDirectory, 'temp'),
        TMP: path.join(dataDirectory, 'temp'),
        XDG_CONFIG_HOME: path.join(dataDirectory, 'runtime'),
        WRANGLER_SEND_METRICS: 'false',
        WRANGLER_WRITE_LOGS: 'false',
        WRANGLER_LOG_PATH: path.join(dataDirectory, 'runtime', 'logs'),
        MINIFLARE_REGISTRY_PATH: path.join(dataDirectory, 'runtime', 'registry'),
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    },
  );

  let errorText = '';
  serverProcess.stderr.on('data', (chunk) => {
    errorText = `${errorText}${chunk}`.slice(-4000);
  });
  serverProcess.on('error', (error) => {
    recordStartupError(`本地服务无法启动：${error.message}`);
  });
  serverProcess.on('exit', (code) => {
    if (!quitting) {
      recordStartupError(errorText || `后台服务退出，代码 ${code}`);
      if (mainWindow) {
        dialog.showErrorBox('后台服务已停止', '请关闭后重新打开盘上造物。详细原因见 data/startup-error.log。');
        app.quit();
      }
    }
  });
}

function waitForServer(timeoutMs = 90000) {
  const startedAt = Date.now();
  return new Promise((resolve, reject) => {
    const check = () => {
      if (serverError) return reject(new Error(serverError));
      if (serverProcess?.exitCode !== null) return reject(new Error(serverError || `本地服务已退出，代码 ${serverProcess.exitCode}`));
      const request = http.get(`http://127.0.0.1:${PORT}/`, (response) => {
        response.resume();
        if ((response.statusCode || 500) < 500) resolve();
        else retry();
      });
      request.on('error', retry);
      request.setTimeout(1500, () => request.destroy());
    };
    const retry = () => {
      if (Date.now() - startedAt > timeoutMs) reject(new Error('本地服务启动超时'));
      else setTimeout(check, 500);
    };
    check();
  });
}

async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 980,
    minHeight: 680,
    show: false,
    backgroundColor: '#f1f1ed',
    title: '盘上造物 · 菜品图像工作台',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) void shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (new URL(url).origin !== `http://127.0.0.1:${PORT}`) {
      event.preventDefault();
      if (/^https?:/.test(url)) void shell.openExternal(url);
    }
  });
  mainWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent('<style>body{margin:0;display:grid;place-items:center;height:100vh;background:#f1f1ed;font:16px system-ui;color:#171815}.box{text-align:center}.dot{width:38px;height:38px;margin:auto;border:4px solid #d9ff43;border-top-color:#171815;border-radius:50%;animation:s 1s linear infinite}@keyframes s{to{transform:rotate(360deg)}}</style><div class="box"><div class="dot"></div><p>正在启动盘上造物…</p></div>')}`);
  mainWindow.show();

  try {
    await waitForServer();
    await mainWindow.loadURL(`http://127.0.0.1:${PORT}/`);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    recordStartupError(message);
    dialog.showErrorBox('启动失败', `${message}\n错误记录保存在程序数据目录的 startup-error.log。`);
    app.quit();
  }
}

app.whenReady().then(async () => {
  if (!hasLock) return;
  try {
    await assertPortAvailable();
    startServer(await startConfigServer());
    await createWindow();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    recordStartupError(message);
    dialog.showErrorBox('启动失败', message);
    app.quit();
  }
});

app.on('window-all-closed', () => app.quit());
app.on('before-quit', () => {
  quitting = true;
  if (serverProcess?.pid && !serverProcess.killed) {
    if (process.platform === 'win32') spawnSync('taskkill', ['/pid', String(serverProcess.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
    else serverProcess.kill();
  }
  configServer?.close();
});
